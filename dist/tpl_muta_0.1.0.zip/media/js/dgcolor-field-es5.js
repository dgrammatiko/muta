(function () {
  'use strict';

  function _regeneratorRuntime() {
    _regeneratorRuntime = function () {
      return exports;
    };
    var exports = {},
      Op = Object.prototype,
      hasOwn = Op.hasOwnProperty,
      defineProperty = Object.defineProperty || function (obj, key, desc) {
        obj[key] = desc.value;
      },
      $Symbol = "function" == typeof Symbol ? Symbol : {},
      iteratorSymbol = $Symbol.iterator || "@@iterator",
      asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator",
      toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
      return Object.defineProperty(obj, key, {
        value: value,
        enumerable: !0,
        configurable: !0,
        writable: !0
      }), obj[key];
    }
    try {
      define({}, "");
    } catch (err) {
      define = function (obj, key, value) {
        return obj[key] = value;
      };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
      var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator,
        generator = Object.create(protoGenerator.prototype),
        context = new Context(tryLocsList || []);
      return defineProperty(generator, "_invoke", {
        value: makeInvokeMethod(innerFn, self, context)
      }), generator;
    }
    function tryCatch(fn, obj, arg) {
      try {
        return {
          type: "normal",
          arg: fn.call(obj, arg)
        };
      } catch (err) {
        return {
          type: "throw",
          arg: err
        };
      }
    }
    exports.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function () {
      return this;
    });
    var getProto = Object.getPrototypeOf,
      NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
      ["next", "throw", "return"].forEach(function (method) {
        define(prototype, method, function (arg) {
          return this._invoke(method, arg);
        });
      });
    }
    function AsyncIterator(generator, PromiseImpl) {
      function invoke(method, arg, resolve, reject) {
        var record = tryCatch(generator[method], generator, arg);
        if ("throw" !== record.type) {
          var result = record.arg,
            value = result.value;
          return value && "object" == typeof value && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function (value) {
            invoke("next", value, resolve, reject);
          }, function (err) {
            invoke("throw", err, resolve, reject);
          }) : PromiseImpl.resolve(value).then(function (unwrapped) {
            result.value = unwrapped, resolve(result);
          }, function (error) {
            return invoke("throw", error, resolve, reject);
          });
        }
        reject(record.arg);
      }
      var previousPromise;
      defineProperty(this, "_invoke", {
        value: function (method, arg) {
          function callInvokeWithMethodAndArg() {
            return new PromiseImpl(function (resolve, reject) {
              invoke(method, arg, resolve, reject);
            });
          }
          return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
        }
      });
    }
    function makeInvokeMethod(innerFn, self, context) {
      var state = "suspendedStart";
      return function (method, arg) {
        if ("executing" === state) throw new Error("Generator is already running");
        if ("completed" === state) {
          if ("throw" === method) throw arg;
          return doneResult();
        }
        for (context.method = method, context.arg = arg;;) {
          var delegate = context.delegate;
          if (delegate) {
            var delegateResult = maybeInvokeDelegate(delegate, context);
            if (delegateResult) {
              if (delegateResult === ContinueSentinel) continue;
              return delegateResult;
            }
          }
          if ("next" === context.method) context.sent = context._sent = context.arg;else if ("throw" === context.method) {
            if ("suspendedStart" === state) throw state = "completed", context.arg;
            context.dispatchException(context.arg);
          } else "return" === context.method && context.abrupt("return", context.arg);
          state = "executing";
          var record = tryCatch(innerFn, self, context);
          if ("normal" === record.type) {
            if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
            return {
              value: record.arg,
              done: context.done
            };
          }
          "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
        }
      };
    }
    function maybeInvokeDelegate(delegate, context) {
      var methodName = context.method,
        method = delegate.iterator[methodName];
      if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator.return && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
      var record = tryCatch(method, delegate.iterator, context.arg);
      if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
      var info = record.arg;
      return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
      var entry = {
        tryLoc: locs[0]
      };
      1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
      var record = entry.completion || {};
      record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
      this.tryEntries = [{
        tryLoc: "root"
      }], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
      if (iterable) {
        var iteratorMethod = iterable[iteratorSymbol];
        if (iteratorMethod) return iteratorMethod.call(iterable);
        if ("function" == typeof iterable.next) return iterable;
        if (!isNaN(iterable.length)) {
          var i = -1,
            next = function next() {
              for (; ++i < iterable.length;) if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
              return next.value = undefined, next.done = !0, next;
            };
          return next.next = next;
        }
      }
      return {
        next: doneResult
      };
    }
    function doneResult() {
      return {
        value: undefined,
        done: !0
      };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
      value: GeneratorFunctionPrototype,
      configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
      value: GeneratorFunction,
      configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports.isGeneratorFunction = function (genFun) {
      var ctor = "function" == typeof genFun && genFun.constructor;
      return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports.mark = function (genFun) {
      return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports.awrap = function (arg) {
      return {
        __await: arg
      };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function () {
      return this;
    }), exports.AsyncIterator = AsyncIterator, exports.async = function (innerFn, outerFn, self, tryLocsList, PromiseImpl) {
      void 0 === PromiseImpl && (PromiseImpl = Promise);
      var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
      return exports.isGeneratorFunction(outerFn) ? iter : iter.next().then(function (result) {
        return result.done ? result.value : iter.next();
      });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function () {
      return this;
    }), define(Gp, "toString", function () {
      return "[object Generator]";
    }), exports.keys = function (val) {
      var object = Object(val),
        keys = [];
      for (var key in object) keys.push(key);
      return keys.reverse(), function next() {
        for (; keys.length;) {
          var key = keys.pop();
          if (key in object) return next.value = key, next.done = !1, next;
        }
        return next.done = !0, next;
      };
    }, exports.values = values, Context.prototype = {
      constructor: Context,
      reset: function (skipTempReset) {
        if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for (var name in this) "t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
      },
      stop: function () {
        this.done = !0;
        var rootRecord = this.tryEntries[0].completion;
        if ("throw" === rootRecord.type) throw rootRecord.arg;
        return this.rval;
      },
      dispatchException: function (exception) {
        if (this.done) throw exception;
        var context = this;
        function handle(loc, caught) {
          return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
        }
        for (var i = this.tryEntries.length - 1; i >= 0; --i) {
          var entry = this.tryEntries[i],
            record = entry.completion;
          if ("root" === entry.tryLoc) return handle("end");
          if (entry.tryLoc <= this.prev) {
            var hasCatch = hasOwn.call(entry, "catchLoc"),
              hasFinally = hasOwn.call(entry, "finallyLoc");
            if (hasCatch && hasFinally) {
              if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
              if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
            } else if (hasCatch) {
              if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
            } else {
              if (!hasFinally) throw new Error("try statement without catch or finally");
              if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
            }
          }
        }
      },
      abrupt: function (type, arg) {
        for (var i = this.tryEntries.length - 1; i >= 0; --i) {
          var entry = this.tryEntries[i];
          if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
            var finallyEntry = entry;
            break;
          }
        }
        finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
        var record = finallyEntry ? finallyEntry.completion : {};
        return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
      },
      complete: function (record, afterLoc) {
        if ("throw" === record.type) throw record.arg;
        return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
      },
      finish: function (finallyLoc) {
        for (var i = this.tryEntries.length - 1; i >= 0; --i) {
          var entry = this.tryEntries[i];
          if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
        }
      },
      catch: function (tryLoc) {
        for (var i = this.tryEntries.length - 1; i >= 0; --i) {
          var entry = this.tryEntries[i];
          if (entry.tryLoc === tryLoc) {
            var record = entry.completion;
            if ("throw" === record.type) {
              var thrown = record.arg;
              resetTryEntry(entry);
            }
            return thrown;
          }
        }
        throw new Error("illegal catch attempt");
      },
      delegateYield: function (iterable, resultName, nextLoc) {
        return this.delegate = {
          iterator: values(iterable),
          resultName: resultName,
          nextLoc: nextLoc
        }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
      }
    }, exports;
  }
  function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
      var info = gen[key](arg);
      var value = info.value;
    } catch (error) {
      reject(error);
      return;
    }
    if (info.done) {
      resolve(value);
    } else {
      Promise.resolve(value).then(_next, _throw);
    }
  }
  function _asyncToGenerator(fn) {
    return function () {
      var self = this,
        args = arguments;
      return new Promise(function (resolve, reject) {
        var gen = fn.apply(self, args);
        function _next(value) {
          asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
        }
        function _throw(err) {
          asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
        }
        _next(undefined);
      });
    };
  }
  function _defineProperties(target, props) {
    for (var i = 0; i < props.length; i++) {
      var descriptor = props[i];
      descriptor.enumerable = descriptor.enumerable || false;
      descriptor.configurable = true;
      if ("value" in descriptor) descriptor.writable = true;
      Object.defineProperty(target, _toPropertyKey(descriptor.key), descriptor);
    }
  }
  function _createClass(Constructor, protoProps, staticProps) {
    if (protoProps) _defineProperties(Constructor.prototype, protoProps);
    if (staticProps) _defineProperties(Constructor, staticProps);
    Object.defineProperty(Constructor, "prototype", {
      writable: false
    });
    return Constructor;
  }
  function _inheritsLoose(subClass, superClass) {
    subClass.prototype = Object.create(superClass.prototype);
    subClass.prototype.constructor = subClass;
    _setPrototypeOf(subClass, superClass);
  }
  function _getPrototypeOf(o) {
    _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function _getPrototypeOf(o) {
      return o.__proto__ || Object.getPrototypeOf(o);
    };
    return _getPrototypeOf(o);
  }
  function _setPrototypeOf(o, p) {
    _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function _setPrototypeOf(o, p) {
      o.__proto__ = p;
      return o;
    };
    return _setPrototypeOf(o, p);
  }
  function _isNativeReflectConstruct() {
    if (typeof Reflect === "undefined" || !Reflect.construct) return false;
    if (Reflect.construct.sham) return false;
    if (typeof Proxy === "function") return true;
    try {
      Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
      return true;
    } catch (e) {
      return false;
    }
  }
  function _construct(Parent, args, Class) {
    if (_isNativeReflectConstruct()) {
      _construct = Reflect.construct.bind();
    } else {
      _construct = function _construct(Parent, args, Class) {
        var a = [null];
        a.push.apply(a, args);
        var Constructor = Function.bind.apply(Parent, a);
        var instance = new Constructor();
        if (Class) _setPrototypeOf(instance, Class.prototype);
        return instance;
      };
    }
    return _construct.apply(null, arguments);
  }
  function _isNativeFunction(fn) {
    return Function.toString.call(fn).indexOf("[native code]") !== -1;
  }
  function _wrapNativeSuper(Class) {
    var _cache = typeof Map === "function" ? new Map() : undefined;
    _wrapNativeSuper = function _wrapNativeSuper(Class) {
      if (Class === null || !_isNativeFunction(Class)) return Class;
      if (typeof Class !== "function") {
        throw new TypeError("Super expression must either be null or a function");
      }
      if (typeof _cache !== "undefined") {
        if (_cache.has(Class)) return _cache.get(Class);
        _cache.set(Class, Wrapper);
      }
      function Wrapper() {
        return _construct(Class, arguments, _getPrototypeOf(this).constructor);
      }
      Wrapper.prototype = Object.create(Class.prototype, {
        constructor: {
          value: Wrapper,
          enumerable: false,
          writable: true,
          configurable: true
        }
      });
      return _setPrototypeOf(Wrapper, Class);
    };
    return _wrapNativeSuper(Class);
  }
  function _assertThisInitialized(self) {
    if (self === void 0) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }
    return self;
  }
  function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
  }
  function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i];
    return arr2;
  }
  function _createForOfIteratorHelperLoose(o, allowArrayLike) {
    var it = typeof Symbol !== "undefined" && o[Symbol.iterator] || o["@@iterator"];
    if (it) return (it = it.call(o)).next.bind(it);
    if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") {
      if (it) o = it;
      var i = 0;
      return function () {
        if (i >= o.length) return {
          done: true
        };
        return {
          done: false,
          value: o[i++]
        };
      };
    }
    throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function _toPrimitive(input, hint) {
    if (typeof input !== "object" || input === null) return input;
    var prim = input[Symbol.toPrimitive];
    if (prim !== undefined) {
      var res = prim.call(input, hint || "default");
      if (typeof res !== "object") return res;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (hint === "string" ? String : Number)(input);
  }
  function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return typeof key === "symbol" ? key : String(key);
  }

  /**
   * @license
   * Copyright 2019 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   */
  var t$1 = window,
    e$2 = t$1.ShadowRoot && (void 0 === t$1.ShadyCSS || t$1.ShadyCSS.nativeShadow) && "adoptedStyleSheets" in Document.prototype && "replace" in CSSStyleSheet.prototype,
    s$3 = Symbol(),
    n$3 = new WeakMap();
  var o$3 = /*#__PURE__*/function () {
    function o(t, e, n) {
      if (this._$cssResult$ = !0, n !== s$3) throw Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");
      this.cssText = t, this.t = e;
    }
    var _proto = o.prototype;
    _proto.toString = function toString() {
      return this.cssText;
    };
    _createClass(o, [{
      key: "styleSheet",
      get: function get() {
        var t = this.o;
        var s = this.t;
        if (e$2 && void 0 === t) {
          var _e = void 0 !== s && 1 === s.length;
          _e && (t = n$3.get(s)), void 0 === t && ((this.o = t = new CSSStyleSheet()).replaceSync(this.cssText), _e && n$3.set(s, t));
        }
        return t;
      }
    }]);
    return o;
  }();
  var r$2 = function r$2(t) {
      return new o$3("string" == typeof t ? t : t + "", void 0, s$3);
    },
    S$1 = function S$1(s, n) {
      e$2 ? s.adoptedStyleSheets = n.map(function (t) {
        return t instanceof CSSStyleSheet ? t : t.styleSheet;
      }) : n.forEach(function (e) {
        var n = document.createElement("style"),
          o = t$1.litNonce;
        void 0 !== o && n.setAttribute("nonce", o), n.textContent = e.cssText, s.appendChild(n);
      });
    },
    c$1 = e$2 ? function (t) {
      return t;
    } : function (t) {
      return t instanceof CSSStyleSheet ? function (t) {
        var e = "";
        for (var _iterator = _createForOfIteratorHelperLoose(t.cssRules), _step; !(_step = _iterator()).done;) {
          var _s = _step.value;
          e += _s.cssText;
        }
        return r$2(e);
      }(t) : t;
    };

  /**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   */
  var s$2;
  var e$1 = window,
    r$1 = e$1.trustedTypes,
    h$1 = r$1 ? r$1.emptyScript : "",
    o$2 = e$1.reactiveElementPolyfillSupport,
    n$2 = {
      toAttribute(t, i) {
        switch (i) {
          case Boolean:
            t = t ? h$1 : null;
            break;
          case Object:
          case Array:
            t = null == t ? t : JSON.stringify(t);
        }
        return t;
      },
      fromAttribute(t, i) {
        var s = t;
        switch (i) {
          case Boolean:
            s = null !== t;
            break;
          case Number:
            s = null === t ? null : Number(t);
            break;
          case Object:
          case Array:
            try {
              s = JSON.parse(t);
            } catch (t) {
              s = null;
            }
        }
        return s;
      }
    },
    a$1 = function a$1(t, i) {
      return i !== t && (i == i || t == t);
    },
    l$2 = {
      attribute: !0,
      type: String,
      converter: n$2,
      reflect: !1,
      hasChanged: a$1
    };
  var d$1 = /*#__PURE__*/function (_HTMLElement) {
    _inheritsLoose(d, _HTMLElement);
    function d() {
      var _this;
      _this = _HTMLElement.call(this) || this, _this._$Ei = new Map(), _this.isUpdatePending = !1, _this.hasUpdated = !1, _this._$El = null, _this.u();
      return _this;
    }
    d.addInitializer = function addInitializer(t) {
      var i;
      this.finalize(), (null !== (i = this.h) && void 0 !== i ? i : this.h = []).push(t);
    };
    d.createProperty = function createProperty(t, i) {
      if (i === void 0) {
        i = l$2;
      }
      if (i.state && (i.attribute = !1), this.finalize(), this.elementProperties.set(t, i), !i.noAccessor && !this.prototype.hasOwnProperty(t)) {
        var _s2 = "symbol" == typeof t ? Symbol() : "__" + t,
          _e2 = this.getPropertyDescriptor(t, _s2, i);
        void 0 !== _e2 && Object.defineProperty(this.prototype, t, _e2);
      }
    };
    d.getPropertyDescriptor = function getPropertyDescriptor(t, i, s) {
      return {
        get() {
          return this[i];
        },
        set(e) {
          var r = this[t];
          this[i] = e, this.requestUpdate(t, r, s);
        },
        configurable: !0,
        enumerable: !0
      };
    };
    d.getPropertyOptions = function getPropertyOptions(t) {
      return this.elementProperties.get(t) || l$2;
    };
    d.finalize = function finalize() {
      if (this.hasOwnProperty("finalized")) return !1;
      this.finalized = !0;
      var t = Object.getPrototypeOf(this);
      if (t.finalize(), void 0 !== t.h && (this.h = [].concat(t.h)), this.elementProperties = new Map(t.elementProperties), this._$Ev = new Map(), this.hasOwnProperty("properties")) {
        var _t = this.properties,
          _i = [].concat(Object.getOwnPropertyNames(_t), Object.getOwnPropertySymbols(_t));
        for (var _iterator2 = _createForOfIteratorHelperLoose(_i), _step2; !(_step2 = _iterator2()).done;) {
          var _s3 = _step2.value;
          this.createProperty(_s3, _t[_s3]);
        }
      }
      return this.elementStyles = this.finalizeStyles(this.styles), !0;
    };
    d.finalizeStyles = function finalizeStyles(i) {
      var s = [];
      if (Array.isArray(i)) {
        var _e3 = new Set(i.flat(1 / 0).reverse());
        for (var _iterator3 = _createForOfIteratorHelperLoose(_e3), _step3; !(_step3 = _iterator3()).done;) {
          var _i2 = _step3.value;
          s.unshift(c$1(_i2));
        }
      } else void 0 !== i && s.push(c$1(i));
      return s;
    };
    d._$Ep = function _$Ep(t, i) {
      var s = i.attribute;
      return !1 === s ? void 0 : "string" == typeof s ? s : "string" == typeof t ? t.toLowerCase() : void 0;
    };
    var _proto2 = d.prototype;
    _proto2.u = function u() {
      var _this2 = this;
      var t;
      this._$E_ = new Promise(function (t) {
        return _this2.enableUpdating = t;
      }), this._$AL = new Map(), this._$Eg(), this.requestUpdate(), null === (t = this.constructor.h) || void 0 === t || t.forEach(function (t) {
        return t(_this2);
      });
    };
    _proto2.addController = function addController(t) {
      var i, s;
      (null !== (i = this._$ES) && void 0 !== i ? i : this._$ES = []).push(t), void 0 !== this.renderRoot && this.isConnected && (null === (s = t.hostConnected) || void 0 === s || s.call(t));
    };
    _proto2.removeController = function removeController(t) {
      var i;
      null === (i = this._$ES) || void 0 === i || i.splice(this._$ES.indexOf(t) >>> 0, 1);
    };
    _proto2._$Eg = function _$Eg() {
      var _this3 = this;
      this.constructor.elementProperties.forEach(function (t, i) {
        _this3.hasOwnProperty(i) && (_this3._$Ei.set(i, _this3[i]), delete _this3[i]);
      });
    };
    _proto2.createRenderRoot = function createRenderRoot() {
      var t;
      var s = null !== (t = this.shadowRoot) && void 0 !== t ? t : this.attachShadow(this.constructor.shadowRootOptions);
      return S$1(s, this.constructor.elementStyles), s;
    };
    _proto2.connectedCallback = function connectedCallback() {
      var t;
      void 0 === this.renderRoot && (this.renderRoot = this.createRenderRoot()), this.enableUpdating(!0), null === (t = this._$ES) || void 0 === t || t.forEach(function (t) {
        var i;
        return null === (i = t.hostConnected) || void 0 === i ? void 0 : i.call(t);
      });
    };
    _proto2.enableUpdating = function enableUpdating(t) {};
    _proto2.disconnectedCallback = function disconnectedCallback() {
      var t;
      null === (t = this._$ES) || void 0 === t || t.forEach(function (t) {
        var i;
        return null === (i = t.hostDisconnected) || void 0 === i ? void 0 : i.call(t);
      });
    };
    _proto2.attributeChangedCallback = function attributeChangedCallback(t, i, s) {
      this._$AK(t, s);
    };
    _proto2._$EO = function _$EO(t, i, s) {
      if (s === void 0) {
        s = l$2;
      }
      var e;
      var r = this.constructor._$Ep(t, s);
      if (void 0 !== r && !0 === s.reflect) {
        var _h = (void 0 !== (null === (e = s.converter) || void 0 === e ? void 0 : e.toAttribute) ? s.converter : n$2).toAttribute(i, s.type);
        this._$El = t, null == _h ? this.removeAttribute(r) : this.setAttribute(r, _h), this._$El = null;
      }
    };
    _proto2._$AK = function _$AK(t, i) {
      var s;
      var e = this.constructor,
        r = e._$Ev.get(t);
      if (void 0 !== r && this._$El !== r) {
        var _t2 = e.getPropertyOptions(r),
          _h2 = "function" == typeof _t2.converter ? {
            fromAttribute: _t2.converter
          } : void 0 !== (null === (s = _t2.converter) || void 0 === s ? void 0 : s.fromAttribute) ? _t2.converter : n$2;
        this._$El = r, this[r] = _h2.fromAttribute(i, _t2.type), this._$El = null;
      }
    };
    _proto2.requestUpdate = function requestUpdate(t, i, s) {
      var e = !0;
      void 0 !== t && (((s = s || this.constructor.getPropertyOptions(t)).hasChanged || a$1)(this[t], i) ? (this._$AL.has(t) || this._$AL.set(t, i), !0 === s.reflect && this._$El !== t && (void 0 === this._$EC && (this._$EC = new Map()), this._$EC.set(t, s))) : e = !1), !this.isUpdatePending && e && (this._$E_ = this._$Ej());
    };
    _proto2._$Ej = /*#__PURE__*/function () {
      var _$Ej2 = _asyncToGenerator( /*#__PURE__*/_regeneratorRuntime().mark(function _callee() {
        var t;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                this.isUpdatePending = !0;
                _context.prev = 1;
                _context.next = 4;
                return this._$E_;
              case 4:
                _context.next = 9;
                break;
              case 6:
                _context.prev = 6;
                _context.t0 = _context["catch"](1);
                Promise.reject(_context.t0);
              case 9:
                t = this.scheduleUpdate();
                _context.t1 = null != t;
                if (!_context.t1) {
                  _context.next = 14;
                  break;
                }
                _context.next = 14;
                return t;
              case 14:
                return _context.abrupt("return", !this.isUpdatePending);
              case 15:
              case "end":
                return _context.stop();
            }
          }
        }, _callee, this, [[1, 6]]);
      }));
      function _$Ej() {
        return _$Ej2.apply(this, arguments);
      }
      return _$Ej;
    }();
    _proto2.scheduleUpdate = function scheduleUpdate() {
      return this.performUpdate();
    };
    _proto2.performUpdate = function performUpdate() {
      var _this4 = this;
      var t;
      if (!this.isUpdatePending) return;
      this.hasUpdated, this._$Ei && (this._$Ei.forEach(function (t, i) {
        return _this4[i] = t;
      }), this._$Ei = void 0);
      var i = !1;
      var s = this._$AL;
      try {
        i = this.shouldUpdate(s), i ? (this.willUpdate(s), null === (t = this._$ES) || void 0 === t || t.forEach(function (t) {
          var i;
          return null === (i = t.hostUpdate) || void 0 === i ? void 0 : i.call(t);
        }), this.update(s)) : this._$Ek();
      } catch (t) {
        throw i = !1, this._$Ek(), t;
      }
      i && this._$AE(s);
    };
    _proto2.willUpdate = function willUpdate(t) {};
    _proto2._$AE = function _$AE(t) {
      var i;
      null === (i = this._$ES) || void 0 === i || i.forEach(function (t) {
        var i;
        return null === (i = t.hostUpdated) || void 0 === i ? void 0 : i.call(t);
      }), this.hasUpdated || (this.hasUpdated = !0, this.firstUpdated(t)), this.updated(t);
    };
    _proto2._$Ek = function _$Ek() {
      this._$AL = new Map(), this.isUpdatePending = !1;
    };
    _proto2.getUpdateComplete = function getUpdateComplete() {
      return this._$E_;
    };
    _proto2.shouldUpdate = function shouldUpdate(t) {
      return !0;
    };
    _proto2.update = function update(t) {
      var _this5 = this;
      void 0 !== this._$EC && (this._$EC.forEach(function (t, i) {
        return _this5._$EO(i, _this5[i], t);
      }), this._$EC = void 0), this._$Ek();
    };
    _proto2.updated = function updated(t) {};
    _proto2.firstUpdated = function firstUpdated(t) {};
    _createClass(d, [{
      key: "updateComplete",
      get: function get() {
        return this.getUpdateComplete();
      }
    }], [{
      key: "observedAttributes",
      get: function get() {
        var _this6 = this;
        this.finalize();
        var t = [];
        return this.elementProperties.forEach(function (i, s) {
          var e = _this6._$Ep(s, i);
          void 0 !== e && (_this6._$Ev.set(e, s), t.push(e));
        }), t;
      }
    }]);
    return d;
  }( /*#__PURE__*/_wrapNativeSuper(HTMLElement));
  d$1.finalized = !0, d$1.elementProperties = new Map(), d$1.elementStyles = [], d$1.shadowRootOptions = {
    mode: "open"
  }, null == o$2 || o$2({
    ReactiveElement: d$1
  }), (null !== (s$2 = e$1.reactiveElementVersions) && void 0 !== s$2 ? s$2 : e$1.reactiveElementVersions = []).push("1.5.0");

  /**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   */
  var t;
  var i = window,
    s$1 = i.trustedTypes,
    e = s$1 ? s$1.createPolicy("lit-html", {
      createHTML: function createHTML(t) {
        return t;
      }
    }) : void 0,
    o$1 = `lit$${(Math.random() + "").slice(9)}$`,
    n$1 = "?" + o$1,
    l$1 = `<${n$1}>`,
    h = document,
    r = function r(t) {
      if (t === void 0) {
        t = "";
      }
      return h.createComment(t);
    },
    d = function d(t) {
      return null === t || "object" != typeof t && "function" != typeof t;
    },
    u = Array.isArray,
    c = function c(t) {
      return u(t) || "function" == typeof (null == t ? void 0 : t[Symbol.iterator]);
    },
    v = /<(?:(!--|\/[^a-zA-Z])|(\/?[a-zA-Z][^>\s]*)|(\/?$))/g,
    a = /-->/g,
    f = />/g,
    _ = RegExp(">|[ \t\n\f\r](?:([^\\s\"'>=/]+)([ \t\n\f\r]*=[ \t\n\f\r]*(?:[^ \t\n\f\r\"'`<>=]|(\"|')|))|$)", "g"),
    m = /'/g,
    p = /"/g,
    $ = /^(?:script|style|textarea|title)$/i,
    g = function g(t) {
      return function (i) {
        for (var _len = arguments.length, s = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
          s[_key - 1] = arguments[_key];
        }
        return {
          _$litType$: t,
          strings: i,
          values: s
        };
      };
    },
    y = g(1),
    x = Symbol.for("lit-noChange"),
    b = Symbol.for("lit-nothing"),
    T = new WeakMap(),
    A = h.createTreeWalker(h, 129, null, !1),
    E = function E(t, i) {
      var s = t.length - 1,
        n = [];
      var h,
        r = 2 === i ? "<svg>" : "",
        d = v;
      for (var _i3 = 0; _i3 < s; _i3++) {
        var _s4 = t[_i3];
        var _e4 = void 0,
          _u = void 0,
          _c = -1,
          _g = 0;
        for (; _g < _s4.length && (d.lastIndex = _g, _u = d.exec(_s4), null !== _u);) {
          _g = d.lastIndex, d === v ? "!--" === _u[1] ? d = a : void 0 !== _u[1] ? d = f : void 0 !== _u[2] ? ($.test(_u[2]) && (h = RegExp("</" + _u[2], "g")), d = _) : void 0 !== _u[3] && (d = _) : d === _ ? ">" === _u[0] ? (d = null != h ? h : v, _c = -1) : void 0 === _u[1] ? _c = -2 : (_c = d.lastIndex - _u[2].length, _e4 = _u[1], d = void 0 === _u[3] ? _ : '"' === _u[3] ? p : m) : d === p || d === m ? d = _ : d === a || d === f ? d = v : (d = _, h = void 0);
        }
        var _y = d === _ && t[_i3 + 1].startsWith("/>") ? " " : "";
        r += d === v ? _s4 + l$1 : _c >= 0 ? (n.push(_e4), _s4.slice(0, _c) + "$lit$" + _s4.slice(_c) + o$1 + _y) : _s4 + o$1 + (-2 === _c ? (n.push(void 0), _i3) : _y);
      }
      var u = r + (t[s] || "<?>") + (2 === i ? "</svg>" : "");
      if (!Array.isArray(t) || !t.hasOwnProperty("raw")) throw Error("invalid template strings array");
      return [void 0 !== e ? e.createHTML(u) : u, n];
    };
  var C = /*#__PURE__*/function () {
    function C(_ref, e) {
      var t = _ref.strings,
        i = _ref._$litType$;
      var l;
      this.parts = [];
      var h = 0,
        d = 0;
      var u = t.length - 1,
        c = this.parts,
        _E = E(t, i),
        v = _E[0],
        a = _E[1];
      if (this.el = C.createElement(v, e), A.currentNode = this.el.content, 2 === i) {
        var _t3 = this.el.content,
          _i4 = _t3.firstChild;
        _i4.remove(), _t3.append.apply(_t3, _i4.childNodes);
      }
      for (; null !== (l = A.nextNode()) && c.length < u;) {
        if (1 === l.nodeType) {
          if (l.hasAttributes()) {
            var _t4 = [];
            for (var _iterator4 = _createForOfIteratorHelperLoose(l.getAttributeNames()), _step4; !(_step4 = _iterator4()).done;) {
              var _i7 = _step4.value;
              if (_i7.endsWith("$lit$") || _i7.startsWith(o$1)) {
                var _s5 = a[d++];
                if (_t4.push(_i7), void 0 !== _s5) {
                  var _t6 = l.getAttribute(_s5.toLowerCase() + "$lit$").split(o$1),
                    _i8 = /([.?@])?(.*)/.exec(_s5);
                  c.push({
                    type: 1,
                    index: h,
                    name: _i8[2],
                    strings: _t6,
                    ctor: "." === _i8[1] ? M : "?" === _i8[1] ? k : "@" === _i8[1] ? H : S
                  });
                } else c.push({
                  type: 6,
                  index: h
                });
              }
            }
            for (var _i5 = 0, _t5 = _t4; _i5 < _t5.length; _i5++) {
              var _i6 = _t5[_i5];
              l.removeAttribute(_i6);
            }
          }
          if ($.test(l.tagName)) {
            var _t7 = l.textContent.split(o$1),
              _i9 = _t7.length - 1;
            if (_i9 > 0) {
              l.textContent = s$1 ? s$1.emptyScript : "";
              for (var _s6 = 0; _s6 < _i9; _s6++) {
                l.append(_t7[_s6], r()), A.nextNode(), c.push({
                  type: 2,
                  index: ++h
                });
              }
              l.append(_t7[_i9], r());
            }
          }
        } else if (8 === l.nodeType) if (l.data === n$1) c.push({
          type: 2,
          index: h
        });else {
          var _t8 = -1;
          for (; -1 !== (_t8 = l.data.indexOf(o$1, _t8 + 1));) {
            c.push({
              type: 7,
              index: h
            }), _t8 += o$1.length - 1;
          }
        }
        h++;
      }
    }
    C.createElement = function createElement(t, i) {
      var s = h.createElement("template");
      return s.innerHTML = t, s;
    };
    return C;
  }();
  function P(t, i, s, e) {
    if (s === void 0) {
      s = t;
    }
    var o, n, l, h;
    if (i === x) return i;
    var r = void 0 !== e ? null === (o = s._$Co) || void 0 === o ? void 0 : o[e] : s._$Cl;
    var u = d(i) ? void 0 : i._$litDirective$;
    return (null == r ? void 0 : r.constructor) !== u && (null === (n = null == r ? void 0 : r._$AO) || void 0 === n || n.call(r, !1), void 0 === u ? r = void 0 : (r = new u(t), r._$AT(t, s, e)), void 0 !== e ? (null !== (l = (h = s)._$Co) && void 0 !== l ? l : h._$Co = [])[e] = r : s._$Cl = r), void 0 !== r && (i = P(t, r._$AS(t, i.values), r, e)), i;
  }
  var V = /*#__PURE__*/function () {
    function V(t, i) {
      this.u = [], this._$AN = void 0, this._$AD = t, this._$AM = i;
    }
    var _proto3 = V.prototype;
    _proto3.v = function v(t) {
      var i;
      var _this$_$AD = this._$AD,
        s = _this$_$AD.el.content,
        e = _this$_$AD.parts,
        o = (null !== (i = null == t ? void 0 : t.creationScope) && void 0 !== i ? i : h).importNode(s, !0);
      A.currentNode = o;
      var n = A.nextNode(),
        l = 0,
        r = 0,
        d = e[0];
      for (; void 0 !== d;) {
        if (l === d.index) {
          var _i10 = void 0;
          2 === d.type ? _i10 = new N(n, n.nextSibling, this, t) : 1 === d.type ? _i10 = new d.ctor(n, d.name, d.strings, this, t) : 6 === d.type && (_i10 = new I(n, this, t)), this.u.push(_i10), d = e[++r];
        }
        l !== (null == d ? void 0 : d.index) && (n = A.nextNode(), l++);
      }
      return o;
    };
    _proto3.p = function p(t) {
      var i = 0;
      for (var _iterator5 = _createForOfIteratorHelperLoose(this.u), _step5; !(_step5 = _iterator5()).done;) {
        var _s7 = _step5.value;
        void 0 !== _s7 && (void 0 !== _s7.strings ? (_s7._$AI(t, _s7, i), i += _s7.strings.length - 2) : _s7._$AI(t[i])), i++;
      }
    };
    _createClass(V, [{
      key: "parentNode",
      get: function get() {
        return this._$AM.parentNode;
      }
    }, {
      key: "_$AU",
      get: function get() {
        return this._$AM._$AU;
      }
    }]);
    return V;
  }();
  var N = /*#__PURE__*/function () {
    function N(t, i, s, e) {
      var o;
      this.type = 2, this._$AH = b, this._$AN = void 0, this._$AA = t, this._$AB = i, this._$AM = s, this.options = e, this._$Cm = null === (o = null == e ? void 0 : e.isConnected) || void 0 === o || o;
    }
    var _proto4 = N.prototype;
    _proto4._$AI = function _$AI(t, i) {
      if (i === void 0) {
        i = this;
      }
      t = P(this, t, i), d(t) ? t === b || null == t || "" === t ? (this._$AH !== b && this._$AR(), this._$AH = b) : t !== this._$AH && t !== x && this.g(t) : void 0 !== t._$litType$ ? this.$(t) : void 0 !== t.nodeType ? this.T(t) : c(t) ? this.k(t) : this.g(t);
    };
    _proto4.O = function O(t, i) {
      if (i === void 0) {
        i = this._$AB;
      }
      return this._$AA.parentNode.insertBefore(t, i);
    };
    _proto4.T = function T(t) {
      this._$AH !== t && (this._$AR(), this._$AH = this.O(t));
    };
    _proto4.g = function g(t) {
      this._$AH !== b && d(this._$AH) ? this._$AA.nextSibling.data = t : this.T(h.createTextNode(t)), this._$AH = t;
    };
    _proto4.$ = function $(t) {
      var i;
      var s = t.values,
        e = t._$litType$,
        o = "number" == typeof e ? this._$AC(t) : (void 0 === e.el && (e.el = C.createElement(e.h, this.options)), e);
      if ((null === (i = this._$AH) || void 0 === i ? void 0 : i._$AD) === o) this._$AH.p(s);else {
        var _t9 = new V(o, this),
          _i11 = _t9.v(this.options);
        _t9.p(s), this.T(_i11), this._$AH = _t9;
      }
    };
    _proto4._$AC = function _$AC(t) {
      var i = T.get(t.strings);
      return void 0 === i && T.set(t.strings, i = new C(t)), i;
    };
    _proto4.k = function k(t) {
      u(this._$AH) || (this._$AH = [], this._$AR());
      var i = this._$AH;
      var s,
        e = 0;
      for (var _iterator6 = _createForOfIteratorHelperLoose(t), _step6; !(_step6 = _iterator6()).done;) {
        var _o = _step6.value;
        e === i.length ? i.push(s = new N(this.O(r()), this.O(r()), this, this.options)) : s = i[e], s._$AI(_o), e++;
      }
      e < i.length && (this._$AR(s && s._$AB.nextSibling, e), i.length = e);
    };
    _proto4._$AR = function _$AR(t, i) {
      if (t === void 0) {
        t = this._$AA.nextSibling;
      }
      var s;
      for (null === (s = this._$AP) || void 0 === s || s.call(this, !1, !0, i); t && t !== this._$AB;) {
        var _i12 = t.nextSibling;
        t.remove(), t = _i12;
      }
    };
    _proto4.setConnected = function setConnected(t) {
      var i;
      void 0 === this._$AM && (this._$Cm = t, null === (i = this._$AP) || void 0 === i || i.call(this, t));
    };
    _createClass(N, [{
      key: "_$AU",
      get: function get() {
        var t, i;
        return null !== (i = null === (t = this._$AM) || void 0 === t ? void 0 : t._$AU) && void 0 !== i ? i : this._$Cm;
      }
    }, {
      key: "parentNode",
      get: function get() {
        var t = this._$AA.parentNode;
        var i = this._$AM;
        return void 0 !== i && 11 === t.nodeType && (t = i.parentNode), t;
      }
    }, {
      key: "startNode",
      get: function get() {
        return this._$AA;
      }
    }, {
      key: "endNode",
      get: function get() {
        return this._$AB;
      }
    }]);
    return N;
  }();
  var S = /*#__PURE__*/function () {
    function S(t, i, s, e, o) {
      this.type = 1, this._$AH = b, this._$AN = void 0, this.element = t, this.name = i, this._$AM = e, this.options = o, s.length > 2 || "" !== s[0] || "" !== s[1] ? (this._$AH = Array(s.length - 1).fill(new String()), this.strings = s) : this._$AH = b;
    }
    var _proto5 = S.prototype;
    _proto5._$AI = function _$AI(t, i, s, e) {
      if (i === void 0) {
        i = this;
      }
      var o = this.strings;
      var n = !1;
      if (void 0 === o) t = P(this, t, i, 0), n = !d(t) || t !== this._$AH && t !== x, n && (this._$AH = t);else {
        var _e5 = t;
        var _l, _h3;
        for (t = o[0], _l = 0; _l < o.length - 1; _l++) {
          _h3 = P(this, _e5[s + _l], i, _l), _h3 === x && (_h3 = this._$AH[_l]), n || (n = !d(_h3) || _h3 !== this._$AH[_l]), _h3 === b ? t = b : t !== b && (t += (null != _h3 ? _h3 : "") + o[_l + 1]), this._$AH[_l] = _h3;
        }
      }
      n && !e && this.j(t);
    };
    _proto5.j = function j(t) {
      t === b ? this.element.removeAttribute(this.name) : this.element.setAttribute(this.name, null != t ? t : "");
    };
    _createClass(S, [{
      key: "tagName",
      get: function get() {
        return this.element.tagName;
      }
    }, {
      key: "_$AU",
      get: function get() {
        return this._$AM._$AU;
      }
    }]);
    return S;
  }();
  var M = /*#__PURE__*/function (_S) {
    _inheritsLoose(M, _S);
    function M() {
      var _this7;
      _this7 = _S.apply(this, arguments) || this, _this7.type = 3;
      return _this7;
    }
    var _proto6 = M.prototype;
    _proto6.j = function j(t) {
      this.element[this.name] = t === b ? void 0 : t;
    };
    return M;
  }(S);
  var R = s$1 ? s$1.emptyScript : "";
  var k = /*#__PURE__*/function (_S2) {
    _inheritsLoose(k, _S2);
    function k() {
      var _this8;
      _this8 = _S2.apply(this, arguments) || this, _this8.type = 4;
      return _this8;
    }
    var _proto7 = k.prototype;
    _proto7.j = function j(t) {
      t && t !== b ? this.element.setAttribute(this.name, R) : this.element.removeAttribute(this.name);
    };
    return k;
  }(S);
  var H = /*#__PURE__*/function (_S3) {
    _inheritsLoose(H, _S3);
    function H(t, i, s, e, o) {
      var _this9;
      _this9 = _S3.call(this, t, i, s, e, o) || this, _this9.type = 5;
      return _this9;
    }
    var _proto8 = H.prototype;
    _proto8._$AI = function _$AI(t, i) {
      if (i === void 0) {
        i = this;
      }
      var s;
      if ((t = null !== (s = P(this, t, i, 0)) && void 0 !== s ? s : b) === x) return;
      var e = this._$AH,
        o = t === b && e !== b || t.capture !== e.capture || t.once !== e.once || t.passive !== e.passive,
        n = t !== b && (e === b || o);
      o && this.element.removeEventListener(this.name, this, e), n && this.element.addEventListener(this.name, this, t), this._$AH = t;
    };
    _proto8.handleEvent = function handleEvent(t) {
      var i, s;
      "function" == typeof this._$AH ? this._$AH.call(null !== (s = null === (i = this.options) || void 0 === i ? void 0 : i.host) && void 0 !== s ? s : this.element, t) : this._$AH.handleEvent(t);
    };
    return H;
  }(S);
  var I = /*#__PURE__*/function () {
    function I(t, i, s) {
      this.element = t, this.type = 6, this._$AN = void 0, this._$AM = i, this.options = s;
    }
    var _proto9 = I.prototype;
    _proto9._$AI = function _$AI(t) {
      P(this, t);
    };
    _createClass(I, [{
      key: "_$AU",
      get: function get() {
        return this._$AM._$AU;
      }
    }]);
    return I;
  }();
  var z = i.litHtmlPolyfillSupport;
  null == z || z(C, N), (null !== (t = i.litHtmlVersions) && void 0 !== t ? t : i.litHtmlVersions = []).push("2.5.0");
  var Z = function Z(t, i, s) {
    var e, o;
    var n = null !== (e = null == s ? void 0 : s.renderBefore) && void 0 !== e ? e : i;
    var l = n._$litPart$;
    if (void 0 === l) {
      var _t10 = null !== (o = null == s ? void 0 : s.renderBefore) && void 0 !== o ? o : null;
      n._$litPart$ = l = new N(i.insertBefore(r(), _t10), _t10, void 0, null != s ? s : {});
    }
    return l._$AI(t), l;
  };

  /**
   * @license
   * Copyright 2017 Google LLC
   * SPDX-License-Identifier: BSD-3-Clause
   */
  var l, o;
  var s = /*#__PURE__*/function (_d$) {
    _inheritsLoose(s, _d$);
    function s() {
      var _this10;
      _this10 = _d$.apply(this, arguments) || this, _this10.renderOptions = {
        host: _assertThisInitialized(_this10)
      }, _this10._$Do = void 0;
      return _this10;
    }
    var _proto10 = s.prototype;
    _proto10.createRenderRoot = function createRenderRoot() {
      var t, e;
      var i = _d$.prototype.createRenderRoot.call(this);
      return null !== (t = (e = this.renderOptions).renderBefore) && void 0 !== t || (e.renderBefore = i.firstChild), i;
    };
    _proto10.update = function update(t) {
      var i = this.render();
      this.hasUpdated || (this.renderOptions.isConnected = this.isConnected), _d$.prototype.update.call(this, t), this._$Do = Z(i, this.renderRoot, this.renderOptions);
    };
    _proto10.connectedCallback = function connectedCallback() {
      var t;
      _d$.prototype.connectedCallback.call(this), null === (t = this._$Do) || void 0 === t || t.setConnected(!0);
    };
    _proto10.disconnectedCallback = function disconnectedCallback() {
      var t;
      _d$.prototype.disconnectedCallback.call(this), null === (t = this._$Do) || void 0 === t || t.setConnected(!1);
    };
    _proto10.render = function render() {
      return x;
    };
    return s;
  }(d$1);
  s.finalized = !0, s._$litElement$ = !0, null === (l = globalThis.litElementHydrateSupport) || void 0 === l || l.call(globalThis, {
    LitElement: s
  });
  var n = globalThis.litElementPolyfillSupport;
  null == n || n({
    LitElement: s
  });
  (null !== (o = globalThis.litElementVersions) && void 0 !== o ? o : globalThis.litElementVersions = []).push("3.2.2");

  // Tool Cool Picker v1.0.13, MIT License - https://github.com/toolcool-org/toolcool-color-picker
  (function () {
    var Mt = Object.defineProperty;
    var kt = function kt(o, e, t) {
      return e in o ? Mt(o, e, {
        enumerable: !0,
        configurable: !0,
        writable: !0,
        value: t
      }) : o[e] = t;
    };
    var h = function h(o, e, t) {
      return kt(o, typeof e != "symbol" ? e + "" : e, t), t;
    };
    var ot = ":root{--tool-cool-color-picker-btn-bg:#fff;--tool-cool-color-picker-btn-border-color:#cecece;--tool-cool-color-picker-btn-border-color-inner:#626262;--tool-cool-color-picker-btn-border-radius:.25rem;--tool-cool-color-picker-btn-border-radius-inner:0}.color-picker{position:relative}.button{width:3rem;height:1.5rem;padding:.25rem;background:var(--tool-cool-color-picker-btn-bg,#fff);border-radius:var(--tool-cool-color-picker-btn-border-radius,0.25rem);border-width:1px;border-style:solid;border-color:var(--tool-cool-color-picker-btn-border-color,#cecece);cursor:pointer;box-sizing:border-box}.button-color{display:block;width:100%;height:100%;border-width:1px;border-style:solid;border-color:var(--tool-cool-color-picker-btn-border-color-inner,#626262);background:#000;box-sizing:border-box;border-radius:var(--tool-cool-color-picker-btn-border-radius-inner,0)}";
    var it = ":root{--tool-cool-color-picker-popup-bg:#fff;--tool-cool-color-picker-popup-border-color:#cecece;--tool-cool-color-picker-popup-width:214px}.popup{position:absolute;left:0;top:calc(100% - 1px);z-index:50;width:var(--tool-cool-color-picker-popup-width,214px);box-shadow:0 1px 3px 0 rgba(0,0,0,0.1),0 1px 2px -1px rgba(0,0,0,0.1);padding:.5rem;background:var(--tool-cool-color-picker-popup-bg,#fff);border-width:1px;border-style:solid;border-color:var(--tool-cool-color-picker-popup-border-color,#cecece);border-radius:.25rem}.popup.right{right:0;left:auto}";
    var rt = ".saturation{touch-action:none;overflow:hidden;width:100%;height:9rem;position:relative}.box{width:100%;height:100%;position:absolute}.white{background:linear-gradient(90deg,#fff,hsla(0,0%,100%,0))}.black{background:linear-gradient(0,#000,transparent)}.pointer{top:34.902%;left:18.6747%;cursor:pointer;position:absolute;outline:0}.handler{box-shadow:0 0 0 1.5px #fff,inset 0 0 1px 1px rgb(0,0,0,0.3),0 0 1px 2px rgb(0,0,0,0.4);-webkit-transform:translate(-2px,-2px);transform:translate(-2px,-2px);border-radius:100%;width:.25rem;height:.25rem;outline:0}";
    var p = "tc-hsv-changed",
      f = "tc-hue-changed",
      m = "tc-alpha-changed",
      D = "tc-button-clicked",
      nt = function nt(o) {
        !o || document.dispatchEvent(new CustomEvent(D, {
          detail: {
            cid: o
          }
        }));
      },
      M = function M(o, e) {
        !o || document.dispatchEvent(new CustomEvent(m, {
          detail: {
            a: e,
            cid: o
          }
        }));
      },
      b = function b(o, e, t, i) {
        !o || document.dispatchEvent(new CustomEvent(p, {
          detail: {
            h: e,
            s: t,
            v: i,
            cid: o
          }
        }));
      },
      st = function st(o, e) {
        !o || document.dispatchEvent(new CustomEvent(f, {
          detail: {
            h: e,
            cid: o
          }
        }));
      };
    function u(o, e) {
      St(o) && (o = "100%");
      var t = Tt(o);
      return o = e === 360 ? o : Math.min(e, Math.max(0, parseFloat(o))), t && (o = parseInt(String(o * e), 10) / 100), Math.abs(o - e) < 1e-6 ? 1 : (e === 360 ? o = (o < 0 ? o % e + e : o % e) / parseFloat(String(e)) : o = o % e / parseFloat(String(e)), o);
    }
    function k(o) {
      return Math.min(1, Math.max(0, o));
    }
    function St(o) {
      return typeof o == "string" && o.indexOf(".") !== -1 && parseFloat(o) === 1;
    }
    function Tt(o) {
      return typeof o == "string" && o.indexOf("%") !== -1;
    }
    function P(o) {
      return o = parseFloat(o), (isNaN(o) || o < 0 || o > 1) && (o = 1), o;
    }
    function L(o) {
      return o <= 1 ? "".concat(Number(o) * 100, "%") : o;
    }
    function C(o) {
      return o.length === 1 ? "0" + o : String(o);
    }
    function at(o, e, t) {
      return {
        r: u(o, 255) * 255,
        g: u(e, 255) * 255,
        b: u(t, 255) * 255
      };
    }
    function U(o, e, t) {
      o = u(o, 255), e = u(e, 255), t = u(t, 255);
      var i = Math.max(o, e, t),
        r = Math.min(o, e, t),
        n = 0,
        s = 0,
        a = (i + r) / 2;
      if (i === r) s = 0, n = 0;else {
        var d = i - r;
        switch (s = a > .5 ? d / (2 - i - r) : d / (i + r), i) {
          case o:
            n = (e - t) / d + (e < t ? 6 : 0);
            break;
          case e:
            n = (t - o) / d + 2;
            break;
          case t:
            n = (o - e) / d + 4;
            break;
        }
        n /= 6;
      }
      return {
        h: n,
        s,
        l: a
      };
    }
    function O(o, e, t) {
      return t < 0 && (t += 1), t > 1 && (t -= 1), t < 1 / 6 ? o + (e - o) * (6 * t) : t < 1 / 2 ? e : t < 2 / 3 ? o + (e - o) * (2 / 3 - t) * 6 : o;
    }
    function ht(o, e, t) {
      var i, r, n;
      if (o = u(o, 360), e = u(e, 100), t = u(t, 100), e === 0) r = t, n = t, i = t;else {
        var s = t < .5 ? t * (1 + e) : t + e - t * e,
          a = 2 * t - s;
        i = O(a, s, o + 1 / 3), r = O(a, s, o), n = O(a, s, o - 1 / 3);
      }
      return {
        r: i * 255,
        g: r * 255,
        b: n * 255
      };
    }
    function K(o, e, t) {
      o = u(o, 255), e = u(e, 255), t = u(t, 255);
      var i = Math.max(o, e, t),
        r = Math.min(o, e, t),
        n = 0,
        s = i,
        a = i - r,
        d = i === 0 ? 0 : a / i;
      if (i === r) n = 0;else {
        switch (i) {
          case o:
            n = (e - t) / a + (e < t ? 6 : 0);
            break;
          case e:
            n = (t - o) / a + 2;
            break;
          case t:
            n = (o - e) / a + 4;
            break;
        }
        n /= 6;
      }
      return {
        h: n,
        s: d,
        v: s
      };
    }
    function lt(o, e, t) {
      o = u(o, 360) * 6, e = u(e, 100), t = u(t, 100);
      var i = Math.floor(o),
        r = o - i,
        n = t * (1 - e),
        s = t * (1 - r * e),
        a = t * (1 - (1 - r) * e),
        d = i % 6,
        w = [t, s, n, n, a, t][d],
        x = [a, t, t, s, n, n][d],
        R = [n, n, a, t, t, s][d];
      return {
        r: w * 255,
        g: x * 255,
        b: R * 255
      };
    }
    function N(o, e, t, i) {
      var r = [C(Math.round(o).toString(16)), C(Math.round(e).toString(16)), C(Math.round(t).toString(16))];
      return i && r[0].startsWith(r[0].charAt(1)) && r[1].startsWith(r[1].charAt(1)) && r[2].startsWith(r[2].charAt(1)) ? r[0].charAt(0) + r[1].charAt(0) + r[2].charAt(0) : r.join("");
    }
    function dt(o, e, t, i, r) {
      var n = [C(Math.round(o).toString(16)), C(Math.round(e).toString(16)), C(Math.round(t).toString(16)), C(Rt(i))];
      return r && n[0].startsWith(n[0].charAt(1)) && n[1].startsWith(n[1].charAt(1)) && n[2].startsWith(n[2].charAt(1)) && n[3].startsWith(n[3].charAt(1)) ? n[0].charAt(0) + n[1].charAt(0) + n[2].charAt(0) + n[3].charAt(0) : n.join("");
    }
    function Rt(o) {
      return Math.round(parseFloat(o) * 255).toString(16);
    }
    function V(o) {
      return g(o) / 255;
    }
    function g(o) {
      return parseInt(o, 16);
    }
    function ut(o) {
      return {
        r: o >> 16,
        g: (o & 65280) >> 8,
        b: o & 255
      };
    }
    var A = {
      aliceblue: "#f0f8ff",
      antiquewhite: "#faebd7",
      aqua: "#00ffff",
      aquamarine: "#7fffd4",
      azure: "#f0ffff",
      beige: "#f5f5dc",
      bisque: "#ffe4c4",
      black: "#000000",
      blanchedalmond: "#ffebcd",
      blue: "#0000ff",
      blueviolet: "#8a2be2",
      brown: "#a52a2a",
      burlywood: "#deb887",
      cadetblue: "#5f9ea0",
      chartreuse: "#7fff00",
      chocolate: "#d2691e",
      coral: "#ff7f50",
      cornflowerblue: "#6495ed",
      cornsilk: "#fff8dc",
      crimson: "#dc143c",
      cyan: "#00ffff",
      darkblue: "#00008b",
      darkcyan: "#008b8b",
      darkgoldenrod: "#b8860b",
      darkgray: "#a9a9a9",
      darkgreen: "#006400",
      darkgrey: "#a9a9a9",
      darkkhaki: "#bdb76b",
      darkmagenta: "#8b008b",
      darkolivegreen: "#556b2f",
      darkorange: "#ff8c00",
      darkorchid: "#9932cc",
      darkred: "#8b0000",
      darksalmon: "#e9967a",
      darkseagreen: "#8fbc8f",
      darkslateblue: "#483d8b",
      darkslategray: "#2f4f4f",
      darkslategrey: "#2f4f4f",
      darkturquoise: "#00ced1",
      darkviolet: "#9400d3",
      deeppink: "#ff1493",
      deepskyblue: "#00bfff",
      dimgray: "#696969",
      dimgrey: "#696969",
      dodgerblue: "#1e90ff",
      firebrick: "#b22222",
      floralwhite: "#fffaf0",
      forestgreen: "#228b22",
      fuchsia: "#ff00ff",
      gainsboro: "#dcdcdc",
      ghostwhite: "#f8f8ff",
      goldenrod: "#daa520",
      gold: "#ffd700",
      gray: "#808080",
      green: "#008000",
      greenyellow: "#adff2f",
      grey: "#808080",
      honeydew: "#f0fff0",
      hotpink: "#ff69b4",
      indianred: "#cd5c5c",
      indigo: "#4b0082",
      ivory: "#fffff0",
      khaki: "#f0e68c",
      lavenderblush: "#fff0f5",
      lavender: "#e6e6fa",
      lawngreen: "#7cfc00",
      lemonchiffon: "#fffacd",
      lightblue: "#add8e6",
      lightcoral: "#f08080",
      lightcyan: "#e0ffff",
      lightgoldenrodyellow: "#fafad2",
      lightgray: "#d3d3d3",
      lightgreen: "#90ee90",
      lightgrey: "#d3d3d3",
      lightpink: "#ffb6c1",
      lightsalmon: "#ffa07a",
      lightseagreen: "#20b2aa",
      lightskyblue: "#87cefa",
      lightslategray: "#778899",
      lightslategrey: "#778899",
      lightsteelblue: "#b0c4de",
      lightyellow: "#ffffe0",
      lime: "#00ff00",
      limegreen: "#32cd32",
      linen: "#faf0e6",
      magenta: "#ff00ff",
      maroon: "#800000",
      mediumaquamarine: "#66cdaa",
      mediumblue: "#0000cd",
      mediumorchid: "#ba55d3",
      mediumpurple: "#9370db",
      mediumseagreen: "#3cb371",
      mediumslateblue: "#7b68ee",
      mediumspringgreen: "#00fa9a",
      mediumturquoise: "#48d1cc",
      mediumvioletred: "#c71585",
      midnightblue: "#191970",
      mintcream: "#f5fffa",
      mistyrose: "#ffe4e1",
      moccasin: "#ffe4b5",
      navajowhite: "#ffdead",
      navy: "#000080",
      oldlace: "#fdf5e6",
      olive: "#808000",
      olivedrab: "#6b8e23",
      orange: "#ffa500",
      orangered: "#ff4500",
      orchid: "#da70d6",
      palegoldenrod: "#eee8aa",
      palegreen: "#98fb98",
      paleturquoise: "#afeeee",
      palevioletred: "#db7093",
      papayawhip: "#ffefd5",
      peachpuff: "#ffdab9",
      peru: "#cd853f",
      pink: "#ffc0cb",
      plum: "#dda0dd",
      powderblue: "#b0e0e6",
      purple: "#800080",
      rebeccapurple: "#663399",
      red: "#ff0000",
      rosybrown: "#bc8f8f",
      royalblue: "#4169e1",
      saddlebrown: "#8b4513",
      salmon: "#fa8072",
      sandybrown: "#f4a460",
      seagreen: "#2e8b57",
      seashell: "#fff5ee",
      sienna: "#a0522d",
      silver: "#c0c0c0",
      skyblue: "#87ceeb",
      slateblue: "#6a5acd",
      slategray: "#708090",
      slategrey: "#708090",
      snow: "#fffafa",
      springgreen: "#00ff7f",
      steelblue: "#4682b4",
      tan: "#d2b48c",
      teal: "#008080",
      thistle: "#d8bfd8",
      tomato: "#ff6347",
      turquoise: "#40e0d0",
      violet: "#ee82ee",
      wheat: "#f5deb3",
      white: "#ffffff",
      whitesmoke: "#f5f5f5",
      yellow: "#ffff00",
      yellowgreen: "#9acd32"
    };
    function ct(o) {
      var e = {
          r: 0,
          g: 0,
          b: 0
        },
        t = 1,
        i = null,
        r = null,
        n = null,
        s = !1,
        a = !1;
      return typeof o == "string" && (o = Bt(o)), typeof o == "object" && (E(o.r) && E(o.g) && E(o.b) ? (e = at(o.r, o.g, o.b), s = !0, a = String(o.r).substr(-1) === "%" ? "prgb" : "rgb") : E(o.h) && E(o.s) && E(o.v) ? (i = L(o.s), r = L(o.v), e = lt(o.h, i, r), s = !0, a = "hsv") : E(o.h) && E(o.s) && E(o.l) && (i = L(o.s), n = L(o.l), e = ht(o.h, i, n), s = !0, a = "hsl"), Object.prototype.hasOwnProperty.call(o, "a") && (t = o.a)), t = P(t), {
        ok: s,
        format: o.format || a,
        r: Math.min(255, Math.max(e.r, 0)),
        g: Math.min(255, Math.max(e.g, 0)),
        b: Math.min(255, Math.max(e.b, 0)),
        a: t
      };
    }
    var Dt = "[-\\+]?\\d+%?",
      Pt = "[-\\+]?\\d*\\.\\d+%?",
      y = "(?:".concat(Pt, ")|(?:").concat(Dt, ")"),
      G = "[\\s|\\(]+(".concat(y, ")[,|\\s]+(").concat(y, ")[,|\\s]+(").concat(y, ")\\s*\\)?"),
      F = "[\\s|\\(]+(".concat(y, ")[,|\\s]+(").concat(y, ")[,|\\s]+(").concat(y, ")[,|\\s]+(").concat(y, ")\\s*\\)?"),
      v = {
        CSS_UNIT: new RegExp(y),
        rgb: new RegExp("rgb" + G),
        rgba: new RegExp("rgba" + F),
        hsl: new RegExp("hsl" + G),
        hsla: new RegExp("hsla" + F),
        hsv: new RegExp("hsv" + G),
        hsva: new RegExp("hsva" + F),
        hex3: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
        hex6: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/,
        hex4: /^#?([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})([0-9a-fA-F]{1})$/,
        hex8: /^#?([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})([0-9a-fA-F]{2})$/
      };
    function Bt(o) {
      if (o = o.trim().toLowerCase(), o.length === 0) return !1;
      var e = !1;
      if (A[o]) o = A[o], e = !0;else if (o === "transparent") return {
        r: 0,
        g: 0,
        b: 0,
        a: 0,
        format: "name"
      };
      var t = v.rgb.exec(o);
      return t ? {
        r: t[1],
        g: t[2],
        b: t[3]
      } : (t = v.rgba.exec(o), t ? {
        r: t[1],
        g: t[2],
        b: t[3],
        a: t[4]
      } : (t = v.hsl.exec(o), t ? {
        h: t[1],
        s: t[2],
        l: t[3]
      } : (t = v.hsla.exec(o), t ? {
        h: t[1],
        s: t[2],
        l: t[3],
        a: t[4]
      } : (t = v.hsv.exec(o), t ? {
        h: t[1],
        s: t[2],
        v: t[3]
      } : (t = v.hsva.exec(o), t ? {
        h: t[1],
        s: t[2],
        v: t[3],
        a: t[4]
      } : (t = v.hex8.exec(o), t ? {
        r: g(t[1]),
        g: g(t[2]),
        b: g(t[3]),
        a: V(t[4]),
        format: e ? "name" : "hex8"
      } : (t = v.hex6.exec(o), t ? {
        r: g(t[1]),
        g: g(t[2]),
        b: g(t[3]),
        format: e ? "name" : "hex"
      } : (t = v.hex4.exec(o), t ? {
        r: g(t[1] + t[1]),
        g: g(t[2] + t[2]),
        b: g(t[3] + t[3]),
        a: V(t[4] + t[4]),
        format: e ? "name" : "hex8"
      } : (t = v.hex3.exec(o), t ? {
        r: g(t[1] + t[1]),
        g: g(t[2] + t[2]),
        b: g(t[3] + t[3]),
        format: e ? "name" : "hex"
      } : !1)))))))));
    }
    function E(o) {
      return Boolean(v.CSS_UNIT.exec(String(o)));
    }
    var l = function () {
      function o(e, t) {
        e === void 0 && (e = ""), t === void 0 && (t = {});
        var i;
        if (e instanceof o) return e;
        typeof e == "number" && (e = ut(e)), this.originalInput = e;
        var r = ct(e);
        this.originalInput = e, this.r = r.r, this.g = r.g, this.b = r.b, this.a = r.a, this.roundA = Math.round(100 * this.a) / 100, this.format = (i = t.format) !== null && i !== void 0 ? i : r.format, this.gradientType = t.gradientType, this.r < 1 && (this.r = Math.round(this.r)), this.g < 1 && (this.g = Math.round(this.g)), this.b < 1 && (this.b = Math.round(this.b)), this.isValid = r.ok;
      }
      return o.prototype.isDark = function () {
        return this.getBrightness() < 128;
      }, o.prototype.isLight = function () {
        return !this.isDark();
      }, o.prototype.getBrightness = function () {
        var e = this.toRgb();
        return (e.r * 299 + e.g * 587 + e.b * 114) / 1e3;
      }, o.prototype.getLuminance = function () {
        var e = this.toRgb(),
          t,
          i,
          r,
          n = e.r / 255,
          s = e.g / 255,
          a = e.b / 255;
        return n <= .03928 ? t = n / 12.92 : t = Math.pow((n + .055) / 1.055, 2.4), s <= .03928 ? i = s / 12.92 : i = Math.pow((s + .055) / 1.055, 2.4), a <= .03928 ? r = a / 12.92 : r = Math.pow((a + .055) / 1.055, 2.4), .2126 * t + .7152 * i + .0722 * r;
      }, o.prototype.getAlpha = function () {
        return this.a;
      }, o.prototype.setAlpha = function (e) {
        return this.a = P(e), this.roundA = Math.round(100 * this.a) / 100, this;
      }, o.prototype.toHsv = function () {
        var e = K(this.r, this.g, this.b);
        return {
          h: e.h * 360,
          s: e.s,
          v: e.v,
          a: this.a
        };
      }, o.prototype.toHsvString = function () {
        var e = K(this.r, this.g, this.b),
          t = Math.round(e.h * 360),
          i = Math.round(e.s * 100),
          r = Math.round(e.v * 100);
        return this.a === 1 ? "hsv(".concat(t, ", ").concat(i, "%, ").concat(r, "%)") : "hsva(".concat(t, ", ").concat(i, "%, ").concat(r, "%, ").concat(this.roundA, ")");
      }, o.prototype.toHsl = function () {
        var e = U(this.r, this.g, this.b);
        return {
          h: e.h * 360,
          s: e.s,
          l: e.l,
          a: this.a
        };
      }, o.prototype.toHslString = function () {
        var e = U(this.r, this.g, this.b),
          t = Math.round(e.h * 360),
          i = Math.round(e.s * 100),
          r = Math.round(e.l * 100);
        return this.a === 1 ? "hsl(".concat(t, ", ").concat(i, "%, ").concat(r, "%)") : "hsla(".concat(t, ", ").concat(i, "%, ").concat(r, "%, ").concat(this.roundA, ")");
      }, o.prototype.toHex = function (e) {
        return e === void 0 && (e = !1), N(this.r, this.g, this.b, e);
      }, o.prototype.toHexString = function (e) {
        return e === void 0 && (e = !1), "#" + this.toHex(e);
      }, o.prototype.toHex8 = function (e) {
        return e === void 0 && (e = !1), dt(this.r, this.g, this.b, this.a, e);
      }, o.prototype.toHex8String = function (e) {
        return e === void 0 && (e = !1), "#" + this.toHex8(e);
      }, o.prototype.toRgb = function () {
        return {
          r: Math.round(this.r),
          g: Math.round(this.g),
          b: Math.round(this.b),
          a: this.a
        };
      }, o.prototype.toRgbString = function () {
        var e = Math.round(this.r),
          t = Math.round(this.g),
          i = Math.round(this.b);
        return this.a === 1 ? "rgb(".concat(e, ", ").concat(t, ", ").concat(i, ")") : "rgba(".concat(e, ", ").concat(t, ", ").concat(i, ", ").concat(this.roundA, ")");
      }, o.prototype.toPercentageRgb = function () {
        var e = function e(t) {
          return "".concat(Math.round(u(t, 255) * 100), "%");
        };
        return {
          r: e(this.r),
          g: e(this.g),
          b: e(this.b),
          a: this.a
        };
      }, o.prototype.toPercentageRgbString = function () {
        var e = function e(t) {
          return Math.round(u(t, 255) * 100);
        };
        return this.a === 1 ? "rgb(".concat(e(this.r), "%, ").concat(e(this.g), "%, ").concat(e(this.b), "%)") : "rgba(".concat(e(this.r), "%, ").concat(e(this.g), "%, ").concat(e(this.b), "%, ").concat(this.roundA, ")");
      }, o.prototype.toName = function () {
        if (this.a === 0) return "transparent";
        if (this.a < 1) return !1;
        for (var e = "#" + N(this.r, this.g, this.b, !1), t = 0, i = Object.entries(A); t < i.length; t++) {
          var r = i[t],
            n = r[0],
            s = r[1];
          if (e === s) return n;
        }
        return !1;
      }, o.prototype.toString = function (e) {
        var t = Boolean(e);
        e = e != null ? e : this.format;
        var i = !1,
          r = this.a < 1 && this.a >= 0,
          n = !t && r && (e.startsWith("hex") || e === "name");
        return n ? e === "name" && this.a === 0 ? this.toName() : this.toRgbString() : (e === "rgb" && (i = this.toRgbString()), e === "prgb" && (i = this.toPercentageRgbString()), (e === "hex" || e === "hex6") && (i = this.toHexString()), e === "hex3" && (i = this.toHexString(!0)), e === "hex4" && (i = this.toHex8String(!0)), e === "hex8" && (i = this.toHex8String()), e === "name" && (i = this.toName()), e === "hsl" && (i = this.toHslString()), e === "hsv" && (i = this.toHsvString()), i || this.toHexString());
      }, o.prototype.toNumber = function () {
        return (Math.round(this.r) << 16) + (Math.round(this.g) << 8) + Math.round(this.b);
      }, o.prototype.clone = function () {
        return new o(this.toString());
      }, o.prototype.lighten = function (e) {
        e === void 0 && (e = 10);
        var t = this.toHsl();
        return t.l += e / 100, t.l = k(t.l), new o(t);
      }, o.prototype.brighten = function (e) {
        e === void 0 && (e = 10);
        var t = this.toRgb();
        return t.r = Math.max(0, Math.min(255, t.r - Math.round(255 * -(e / 100)))), t.g = Math.max(0, Math.min(255, t.g - Math.round(255 * -(e / 100)))), t.b = Math.max(0, Math.min(255, t.b - Math.round(255 * -(e / 100)))), new o(t);
      }, o.prototype.darken = function (e) {
        e === void 0 && (e = 10);
        var t = this.toHsl();
        return t.l -= e / 100, t.l = k(t.l), new o(t);
      }, o.prototype.tint = function (e) {
        return e === void 0 && (e = 10), this.mix("white", e);
      }, o.prototype.shade = function (e) {
        return e === void 0 && (e = 10), this.mix("black", e);
      }, o.prototype.desaturate = function (e) {
        e === void 0 && (e = 10);
        var t = this.toHsl();
        return t.s -= e / 100, t.s = k(t.s), new o(t);
      }, o.prototype.saturate = function (e) {
        e === void 0 && (e = 10);
        var t = this.toHsl();
        return t.s += e / 100, t.s = k(t.s), new o(t);
      }, o.prototype.greyscale = function () {
        return this.desaturate(100);
      }, o.prototype.spin = function (e) {
        var t = this.toHsl(),
          i = (t.h + e) % 360;
        return t.h = i < 0 ? 360 + i : i, new o(t);
      }, o.prototype.mix = function (e, t) {
        t === void 0 && (t = 50);
        var i = this.toRgb(),
          r = new o(e).toRgb(),
          n = t / 100,
          s = {
            r: (r.r - i.r) * n + i.r,
            g: (r.g - i.g) * n + i.g,
            b: (r.b - i.b) * n + i.b,
            a: (r.a - i.a) * n + i.a
          };
        return new o(s);
      }, o.prototype.analogous = function (e, t) {
        e === void 0 && (e = 6), t === void 0 && (t = 30);
        var i = this.toHsl(),
          r = 360 / t,
          n = [this];
        for (i.h = (i.h - (r * e >> 1) + 720) % 360; --e;) {
          i.h = (i.h + r) % 360, n.push(new o(i));
        }
        return n;
      }, o.prototype.complement = function () {
        var e = this.toHsl();
        return e.h = (e.h + 180) % 360, new o(e);
      }, o.prototype.monochromatic = function (e) {
        e === void 0 && (e = 6);
        for (var t = this.toHsv(), i = t.h, r = t.s, n = t.v, s = [], a = 1 / e; e--;) {
          s.push(new o({
            h: i,
            s: r,
            v: n
          })), n = (n + a) % 1;
        }
        return s;
      }, o.prototype.splitcomplement = function () {
        var e = this.toHsl(),
          t = e.h;
        return [this, new o({
          h: (t + 72) % 360,
          s: e.s,
          l: e.l
        }), new o({
          h: (t + 216) % 360,
          s: e.s,
          l: e.l
        })];
      }, o.prototype.onBackground = function (e) {
        var t = this.toRgb(),
          i = new o(e).toRgb();
        return new o({
          r: i.r + (t.r - i.r) * t.a,
          g: i.g + (t.g - i.g) * t.a,
          b: i.b + (t.b - i.b) * t.a
        });
      }, o.prototype.triad = function () {
        return this.polyad(3);
      }, o.prototype.tetrad = function () {
        return this.polyad(4);
      }, o.prototype.polyad = function (e) {
        for (var t = this.toHsl(), i = t.h, r = [this], n = 360 / e, s = 1; s < e; s++) {
          r.push(new o({
            h: (i + s * n) % 360,
            s: t.s,
            l: t.l
          }));
        }
        return r;
      }, o.prototype.equals = function (e) {
        return this.toRgbString() === new o(e).toRgbString();
      }, o;
    }();
    var $ = function $() {
        return Math.random().toString(16).slice(2);
      },
      B = function B(o) {
        return Math.round((o + Number.EPSILON) * 100) / 100;
      };
    var H = .01,
      q = function q(o) {
        return o < 0 && (o = 0), o > 360 && (o = 360), `hsl(${Math.round(o)}, 100%, 50%)`;
      },
      z = function z(o) {
        var e = o.toRgb();
        return `linear-gradient(to right, rgba(${e.r},${e.g},${e.b}, 0) 0%, rgba(${e.r},${e.g},${e.b}, 1) 100%)`;
      },
      S = function S(o) {
        var e = o.toRgb();
        return `rgba(${e.r}, ${e.g}, ${e.b}, ${B(e.a)})`;
      },
      pt = function pt(o) {
        var e = o.toHsl();
        return `hsla(${Math.round(e.h)}, ${Math.round(e.s * 100)}%, ${Math.round(e.l * 100)}%, ${B(e.a)})`;
      },
      gt = function gt(o) {
        var e = o.toHsv();
        return `hsva(${Math.round(e.h)}, ${Math.round(e.s * 100)}%, ${Math.round(e.v * 100)}%, ${B(e.a)})`;
      },
      W = function W(o) {
        return o < 0 && (o = 0), o > 1 && (o = 1), `${(-(o * 100) + 100).toFixed(2)}%`;
      },
      X = function X(o) {
        return o < 0 && (o = 0), o > 1 && (o = 1), `${(o * 100).toFixed(2)}%`;
      },
      T = function T(o) {
        o < 0 && (o = 0), o > 360 && (o = 360);
        var e = o * 100 / 360,
          t = Math.round(e * 100) / 100;
        return t < 0 && (t = 0), t > 100 && (t = 100), t;
      },
      _ = function _(o) {
        return 360 * o / 100;
      },
      I = function I(o) {
        var e = Number(o) || 0;
        return e = Math.round(e), e = Math.max(0, e), e = Math.min(255, e), e;
      },
      ft = function ft(o) {
        var e = Number(o) || 100;
        return e = Math.round(e), e = Math.max(0, e), e = Math.min(100, e), e;
      },
      c = function c(o) {
        var e = new l(o || "#000");
        return e.setAlpha(e.getAlpha()), e;
      };
    var j = /*#__PURE__*/function (_HTMLElement2) {
        _inheritsLoose(j, _HTMLElement2);
        function j() {
          var _this11;
          _this11 = _HTMLElement2.call(this) || this;
          h(_assertThisInitialized(_this11), "cid");
          h(_assertThisInitialized(_this11), "$saturation");
          h(_assertThisInitialized(_this11), "$color");
          h(_assertThisInitialized(_this11), "$pointer");
          h(_assertThisInitialized(_this11), "hue", 0);
          h(_assertThisInitialized(_this11), "saturation", 0);
          h(_assertThisInitialized(_this11), "value", 0);
          _this11.attachShadow({
            mode: "open"
          }), _this11.onMouseDown = _this11.onMouseDown.bind(_assertThisInitialized(_this11)), _this11.onMouseUp = _this11.onMouseUp.bind(_assertThisInitialized(_this11)), _this11.onChange = _this11.onChange.bind(_assertThisInitialized(_this11)), _this11.onPointerKeyDown = _this11.onPointerKeyDown.bind(_assertThisInitialized(_this11)), _this11.hsvChanged = _this11.hsvChanged.bind(_assertThisInitialized(_this11)), _this11.hueChanged = _this11.hueChanged.bind(_assertThisInitialized(_this11));
          return _this11;
        }
        var _proto11 = j.prototype;
        _proto11.render = function render(t) {
          if (t === void 0) {
            t = !0;
          }
          this.$pointer && (this.$pointer.style.left = X(this.saturation), this.$pointer.style.top = W(this.value)), this.$color && this.$color.setAttribute("style", `background: ${q(this.hue)}`), t && b(this.cid, this.hue, this.saturation, this.value);
        };
        _proto11.onChange = function onChange(t) {
          if (!this.$saturation) return;
          var _this$$saturation$get = this.$saturation.getBoundingClientRect(),
            i = _this$$saturation$get.width,
            r = _this$$saturation$get.height,
            n = _this$$saturation$get.left,
            s = _this$$saturation$get.top;
          if (i === 0 || r === 0) return;
          var a = typeof t.clientX == "number" ? t.clientX : t.touches[0].clientX,
            d = typeof t.clientY == "number" ? t.clientY : t.touches[0].clientY,
            w = Math.min(Math.max(0, a - n), i),
            x = Math.min(Math.max(0, d - s), r);
          this.saturation = w / i, this.value = 1 - x / r, this.render();
        };
        _proto11.onPointerKeyDown = function onPointerKeyDown(t) {
          switch (t.key) {
            case "ArrowLeft":
              {
                this.saturation = Math.max(0, this.saturation - H), this.render();
                break;
              }
            case "ArrowRight":
              {
                this.saturation = Math.min(1, this.saturation + H), this.render();
                break;
              }
            case "ArrowUp":
              {
                this.value = Math.min(1, this.value + H), this.render();
                break;
              }
            case "ArrowDown":
              {
                t.preventDefault(), this.value = Math.max(0, this.value - H), this.render();
                break;
              }
          }
        };
        _proto11.onMouseDown = function onMouseDown(t) {
          var _this12 = this;
          t.preventDefault && t.preventDefault(), this.onChange(t), window.addEventListener("mousemove", this.onChange), window.addEventListener("mouseup", this.onMouseUp), window.setTimeout(function () {
            var i;
            (i = _this12.$pointer) == null || i.focus();
          }, 0);
        };
        _proto11.onMouseUp = function onMouseUp() {
          window.removeEventListener("mousemove", this.onChange), window.removeEventListener("mouseup", this.onChange);
        };
        _proto11.hsvChanged = function hsvChanged(t) {
          if (!t || !t.detail || !t.detail.cid || t.detail.cid !== this.cid) return;
          var i = !1;
          this.hue !== t.detail.h && (this.hue = t.detail.h, i = !0), this.saturation !== t.detail.s && (this.saturation = t.detail.s, i = !0), this.value !== t.detail.v && (this.value = t.detail.v, i = !0), i && this.render(!1);
        };
        _proto11.hueChanged = function hueChanged(t) {
          !t || !t.detail || !t.detail.cid || t.detail.cid === this.cid && (this.hue = t.detail.h, this.render());
        };
        _proto11.connectedCallback = function connectedCallback() {
          var s, a, d, w, x;
          if (!this.shadowRoot) return;
          this.cid = this.getAttribute("cid") || "";
          var i = c(this.getAttribute("color")).toHsv();
          this.hue = i.h, this.saturation = i.s, this.value = i.v;
          var r = W(this.value),
            n = X(this.saturation);
          this.shadowRoot.innerHTML = `
           <style>${rt}</style>
           <div class="saturation">
                <div class="box" style="background: ${q(this.hue)}">
                    <div class="white box">
                        <div class="black box"></div>
                        
                        <div class="pointer" tabindex="0" style="top: ${r}; left: ${n};">
                            <div class="handler"></div>
                        </div>
                    </div>
                </div>
           </div>
        `, this.$saturation = this.shadowRoot.querySelector(".saturation"), this.$color = this.shadowRoot.querySelector(".box"), this.$pointer = this.shadowRoot.querySelector(".pointer"), (s = this.$pointer) == null || s.addEventListener("keydown", this.onPointerKeyDown), (a = this.$saturation) == null || a.addEventListener("mousedown", this.onMouseDown), (d = this.$saturation) == null || d.addEventListener("mouseup", this.onMouseUp), (w = this.$saturation) == null || w.addEventListener("touchmove", this.onChange), (x = this.$saturation) == null || x.addEventListener("touchstart", this.onChange), document.addEventListener(p, this.hsvChanged), document.addEventListener(f, this.hueChanged);
        };
        _proto11.disconnectedCallback = function disconnectedCallback() {
          var t, i, r, n, s;
          (t = this.$saturation) == null || t.removeEventListener("mousedown", this.onMouseDown), (i = this.$saturation) == null || i.removeEventListener("mouseup", this.onMouseUp), (r = this.$saturation) == null || r.removeEventListener("touchmove", this.onChange), (n = this.$saturation) == null || n.removeEventListener("touchstart", this.onChange), (s = this.$pointer) == null || s.removeEventListener("keydown", this.onPointerKeyDown), document.removeEventListener(p, this.hsvChanged), document.removeEventListener(f, this.hueChanged);
        };
        _proto11.attributeChangedCallback = function attributeChangedCallback(t, i, r) {
          var s = c(r).toHsv();
          this.hue = s.h, this.saturation = s.s, this.value = s.v, this.render(!1);
        };
        _createClass(j, null, [{
          key: "observedAttributes",
          get: function get() {
            return ["color"];
          }
        }]);
        return j;
      }( /*#__PURE__*/_wrapNativeSuper(HTMLElement)),
      bt = j;
    var vt = ".hue{overflow:hidden;height:.625rem;margin-bottom:.25rem;margin-top:.25rem;position:relative}.box{width:100%;height:100%;position:absolute}.hue-v{background:linear-gradient(0,red 0,#ff0 17%,#0f0 33%,#0ff 50%,#00f 67%,#f0f 83%,red)}.hue-h{background:linear-gradient(90deg,red 0,#ff0 17%,#0f0 33%,#0ff 50%,#00f 67%,#f0f 83%,red);width:100%;height:100%;position:relative}.pointer-box{left:87%;position:absolute;outline:0}.handler{background:#fff;box-shadow:0 0 2px rgb(0 0 0 / 60%);box-sizing:border-box;border:1px solid hsla(0,0%,88%,.5);height:8px;margin-top:1px;-webkit-transform:translateX(-4px);transform:translateX(-4px);width:8px;cursor:pointer;outline:0}.pointer-box:focus .handler{border:2px solid hsla(0,0%,88%,1)}";
    var Y = /*#__PURE__*/function (_HTMLElement3) {
        _inheritsLoose(Y, _HTMLElement3);
        function Y() {
          var _this13;
          _this13 = _HTMLElement3.call(this) || this;
          h(_assertThisInitialized(_this13), "cid");
          h(_assertThisInitialized(_this13), "$hue");
          h(_assertThisInitialized(_this13), "$pointer");
          h(_assertThisInitialized(_this13), "hue", 0);
          _this13.attachShadow({
            mode: "open"
          }), _this13.onMouseDown = _this13.onMouseDown.bind(_assertThisInitialized(_this13)), _this13.onMouseUp = _this13.onMouseUp.bind(_assertThisInitialized(_this13)), _this13.onChange = _this13.onChange.bind(_assertThisInitialized(_this13)), _this13.onKeyDown = _this13.onKeyDown.bind(_assertThisInitialized(_this13)), _this13.hsvChanged = _this13.hsvChanged.bind(_assertThisInitialized(_this13));
          return _this13;
        }
        var _proto12 = Y.prototype;
        _proto12.render = function render() {
          this.$pointer && (this.$pointer.style.left = `${T(this.hue)}%`), st(this.cid, this.hue);
        };
        _proto12.hsvChanged = function hsvChanged(t) {
          !t || !t.detail || !t.detail.cid || t.detail.cid === this.cid && this.hue !== t.detail.h && (this.hue = t.detail.h, this.render());
        };
        _proto12.onChange = function onChange(t) {
          if (!this.$hue) return;
          t.preventDefault && t.preventDefault();
          var _this$$hue$getBoundin = this.$hue.getBoundingClientRect(),
            i = _this$$hue$getBoundin.width,
            r = _this$$hue$getBoundin.left;
          if (i === 0) return;
          var n = typeof t.clientX == "number" ? t.clientX : t.touches[0].clientX,
            s = Math.min(Math.max(0, n - r), i),
            a = Math.min(Math.max(0, Math.round(s * 100 / i)), 100);
          this.hue = _(a), this.render();
        };
        _proto12.onKeyDown = function onKeyDown(t) {
          var i;
          switch ((i = this.$pointer) == null || i.focus(), t.key) {
            case "ArrowLeft":
              {
                var _r = T(this.hue);
                _r = Math.max(0, _r - 1), this.hue = _(_r), this.render();
                break;
              }
            case "ArrowRight":
              {
                var _r2 = T(this.hue);
                _r2 = Math.min(100, _r2 + 1), this.hue = _(_r2), this.render();
                break;
              }
          }
        };
        _proto12.onMouseDown = function onMouseDown(t) {
          var _this14 = this;
          t.preventDefault && t.preventDefault(), this.onChange(t), window.addEventListener("mousemove", this.onChange), window.addEventListener("mouseup", this.onMouseUp), window.setTimeout(function () {
            var i;
            (i = _this14.$pointer) == null || i.focus();
          }, 0);
        };
        _proto12.onMouseUp = function onMouseUp() {
          window.removeEventListener("mousemove", this.onChange), window.removeEventListener("mouseup", this.onChange);
        };
        _proto12.connectedCallback = function connectedCallback() {
          var i, r, n, s, a;
          if (!this.shadowRoot) return;
          this.cid = this.getAttribute("cid") || "";
          var t = c(this.getAttribute("color"));
          this.hue = t.toHsv().h, this.shadowRoot.innerHTML = `
           <style>${vt}</style>
           <div class="hue">
                <div class="box">
                    <div class="hue-v box">
                        <div class="hue-h"></div>
                    </div>
                    
                    <div class="pointer box">
                        <div class="pointer-box" tabindex="0" style="left: ${T(this.hue)}%">
                            <div class="handler"></div>
                        </div>
                    </div>
                </div>
           </div>
        `, this.$hue = this.shadowRoot.querySelector(".hue"), this.$pointer = this.shadowRoot.querySelector(".pointer-box"), (i = this.$hue) == null || i.addEventListener("mousedown", this.onMouseDown), (r = this.$hue) == null || r.addEventListener("mouseup", this.onMouseUp), (n = this.$hue) == null || n.addEventListener("touchmove", this.onChange), (s = this.$hue) == null || s.addEventListener("touchstart", this.onChange), (a = this.$pointer) == null || a.addEventListener("keydown", this.onKeyDown), document.addEventListener(p, this.hsvChanged);
        };
        _proto12.disconnectedCallback = function disconnectedCallback() {
          var t, i, r, n, s;
          (t = this.$hue) == null || t.removeEventListener("mousedown", this.onMouseDown), (i = this.$hue) == null || i.removeEventListener("mouseup", this.onMouseUp), (r = this.$hue) == null || r.removeEventListener("touchmove", this.onChange), (n = this.$hue) == null || n.removeEventListener("touchstart", this.onChange), (s = this.$pointer) == null || s.removeEventListener("keydown", this.onKeyDown), document.removeEventListener(p, this.hsvChanged);
        };
        _proto12.attributeChangedCallback = function attributeChangedCallback(t, i, r) {
          var s = c(r).toHsv();
          this.hue = s.h, this.render();
        };
        _createClass(Y, null, [{
          key: "observedAttributes",
          get: function get() {
            return ["color"];
          }
        }]);
        return Y;
      }( /*#__PURE__*/_wrapNativeSuper(HTMLElement)),
      mt = Y;
    var wt = ".alpha{overflow:hidden;height:.625rem;position:relative;background:#fff}.box{width:100%;height:100%;position:absolute}.transparent-bg{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAADFJREFUOE9jZGBgEGHAD97gk2YcNYBhmIQBgWSAP52AwoAQwJvQRg1gACckQoC2gQgAIF8IscwEtKYAAAAASUVORK5CYII=);overflow:hidden}.pointer-box{left:100%;position:absolute;outline:0}.handler{background:#fff;box-shadow:0 0 2px rgb(0 0 0 / 60%);box-sizing:border-box;border:1px solid hsla(0,0%,88%,.5);height:8px;margin-top:1px;-webkit-transform:translateX(-4px);transform:translateX(-4px);width:8px;cursor:pointer;outline:0}.alpha-pointer-box:focus .alpha-pointer-handler{border:2px solid hsla(0,0%,88%,1)}";
    var Q = /*#__PURE__*/function (_HTMLElement4) {
        _inheritsLoose(Q, _HTMLElement4);
        function Q() {
          var _this15;
          _this15 = _HTMLElement4.call(this) || this;
          h(_assertThisInitialized(_this15), "cid");
          h(_assertThisInitialized(_this15), "$alpha");
          h(_assertThisInitialized(_this15), "$color");
          h(_assertThisInitialized(_this15), "$pointer");
          h(_assertThisInitialized(_this15), "alpha", 1);
          h(_assertThisInitialized(_this15), "hue", 0);
          h(_assertThisInitialized(_this15), "saturation", 0);
          h(_assertThisInitialized(_this15), "value", 0);
          _this15.attachShadow({
            mode: "open"
          }), _this15.onMouseDown = _this15.onMouseDown.bind(_assertThisInitialized(_this15)), _this15.onMouseUp = _this15.onMouseUp.bind(_assertThisInitialized(_this15)), _this15.onChange = _this15.onChange.bind(_assertThisInitialized(_this15)), _this15.onKeyDown = _this15.onKeyDown.bind(_assertThisInitialized(_this15)), _this15.hsvChanged = _this15.hsvChanged.bind(_assertThisInitialized(_this15)), _this15.hueChanged = _this15.hueChanged.bind(_assertThisInitialized(_this15)), _this15.alphaChanged = _this15.alphaChanged.bind(_assertThisInitialized(_this15));
          return _this15;
        }
        var _proto13 = Q.prototype;
        _proto13.render = function render(t) {
          if (t === void 0) {
            t = !0;
          }
          if (this.$pointer && (this.$pointer.style.left = `${this.alpha * 100}%`), this.$color) {
            var _i13 = new l({
              h: this.hue,
              s: this.saturation,
              v: this.value,
              a: this.alpha
            });
            this.$color.style.background = z(_i13);
          }
          t && M(this.cid, this.alpha);
        };
        _proto13.onChange = function onChange(t) {
          if (!this.$alpha) return;
          t.preventDefault && t.preventDefault();
          var _this$$alpha$getBound = this.$alpha.getBoundingClientRect(),
            i = _this$$alpha$getBound.width,
            r = _this$$alpha$getBound.left;
          if (i === 0) return;
          var n = typeof t.clientX == "number" ? t.clientX : t.touches[0].clientX,
            s = Math.min(Math.max(0, n - r), i),
            a = Math.min(Math.max(0, s * 100 / i), 100);
          this.alpha = a / 100, this.render();
        };
        _proto13.onKeyDown = function onKeyDown(t) {
          var i;
          switch ((i = this.$pointer) == null || i.focus(), t.key) {
            case "ArrowLeft":
              {
                var _r3 = this.alpha * 100;
                _r3 = Math.max(0, _r3 - 1), this.alpha = _r3 / 100, this.render();
                break;
              }
            case "ArrowRight":
              {
                var _r4 = this.alpha * 100;
                _r4 = Math.min(100, _r4 + 1), this.alpha = _r4 / 100, this.render();
                break;
              }
          }
        };
        _proto13.hsvChanged = function hsvChanged(t) {
          !t || !t.detail || !t.detail.cid || t.detail.cid === this.cid && (this.saturation = t.detail.h, this.hue = t.detail.s, this.value = t.detail.v, this.render(!1));
        };
        _proto13.hueChanged = function hueChanged(t) {
          !t || !t.detail || !t.detail.cid || t.detail.cid === this.cid && (this.hue = t.detail.h, this.render(!1));
        };
        _proto13.alphaChanged = function alphaChanged(t) {
          !t || !t.detail || !t.detail.cid || t.detail.cid === this.cid && this.alpha !== t.detail.a && (this.alpha = t.detail.a, this.render());
        };
        _proto13.onMouseDown = function onMouseDown(t) {
          var _this16 = this;
          t.preventDefault && t.preventDefault(), this.onChange(t), window.addEventListener("mousemove", this.onChange), window.addEventListener("mouseup", this.onMouseUp), window.setTimeout(function () {
            var i;
            (i = _this16.$pointer) == null || i.focus();
          }, 0);
        };
        _proto13.onMouseUp = function onMouseUp() {
          window.removeEventListener("mousemove", this.onChange), window.removeEventListener("mouseup", this.onChange);
        };
        _proto13.connectedCallback = function connectedCallback() {
          var r, n, s, a, d;
          if (!this.shadowRoot) return;
          this.cid = this.getAttribute("cid") || "";
          var t = c(this.getAttribute("color")),
            i = t.toHsv();
          this.alpha = i.a, this.hue = i.h, this.saturation = i.s, this.value = i.v, this.shadowRoot.innerHTML = `
           <style>${wt}</style>
           <div class="alpha">
                <div class="box">
                    <div class="transparent-bg box"></div>
                    <div class="color-bg box" style="background: ${z(t)}"></div>
                    
                    <div class="pointer box">
                        <div class="pointer-box" tabindex="0" style="left: ${this.alpha * 100}%;" >
                            <div class="handler"></div>
                        </div>
                    </div>
                </div>
           </div>
        `, this.$alpha = this.shadowRoot.querySelector(".alpha"), this.$color = this.shadowRoot.querySelector(".color-bg"), this.$pointer = this.shadowRoot.querySelector(".pointer-box"), (r = this.$alpha) == null || r.addEventListener("mousedown", this.onMouseDown), (n = this.$alpha) == null || n.addEventListener("mouseup", this.onMouseUp), (s = this.$alpha) == null || s.addEventListener("touchmove", this.onChange), (a = this.$alpha) == null || a.addEventListener("touchstart", this.onChange), (d = this.$pointer) == null || d.addEventListener("keydown", this.onKeyDown), document.addEventListener(p, this.hsvChanged), document.addEventListener(f, this.hueChanged), document.addEventListener(m, this.alphaChanged);
        };
        _proto13.disconnectedCallback = function disconnectedCallback() {
          var t, i, r, n, s;
          (t = this.$alpha) == null || t.removeEventListener("mousedown", this.onMouseDown), (i = this.$alpha) == null || i.removeEventListener("mouseup", this.onMouseUp), (r = this.$alpha) == null || r.removeEventListener("touchmove", this.onChange), (n = this.$alpha) == null || n.removeEventListener("touchstart", this.onChange), (s = this.$pointer) == null || s.removeEventListener("keydown", this.onKeyDown), document.removeEventListener(p, this.hsvChanged), document.removeEventListener(f, this.hueChanged), document.removeEventListener(m, this.alphaChanged);
        };
        _proto13.attributeChangedCallback = function attributeChangedCallback(t, i, r) {
          var s = c(r).toHsv();
          this.alpha = s.a, this.hue = s.h, this.saturation = s.s, this.value = s.v, this.render();
        };
        _createClass(Q, null, [{
          key: "observedAttributes",
          get: function get() {
            return ["color"];
          }
        }]);
        return Q;
      }( /*#__PURE__*/_wrapNativeSuper(HTMLElement)),
      xt = Q;
    var Et = ":root{--tool-cool-color-picker-field-border-color:#cecece;--tool-cool-color-picker-field-label-color:#000}.fields{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica Neue,Noto Sans,Liberation Sans,Arial,sans-serif,Apple Color Emoji,Segoe UI Emoji,Segoe UI Symbol,Noto Color Emoji;font-size:11px;grid-template-columns:60px 35px 35px 35px 34px;text-align:center;display:grid;gap:.25rem;margin-top:.25rem;color:var(--tool-cool-color-picker-field-label-color,#000)}.fields input{background:#fff;border-width:1px;border-style:solid;border-color:var(--tool-cool-color-picker-field-border-color,#cecece);padding:1px 3px;border-radius:2px;color:#000;font-family:inherit;font-size:100%;line-height:inherit;margin:0;box-sizing:border-box}";
    var J = /*#__PURE__*/function (_HTMLElement5) {
        _inheritsLoose(J, _HTMLElement5);
        function J() {
          var _this17;
          _this17 = _HTMLElement5.call(this) || this;
          h(_assertThisInitialized(_this17), "cid");
          h(_assertThisInitialized(_this17), "color", new l("#000"));
          h(_assertThisInitialized(_this17), "$hex");
          h(_assertThisInitialized(_this17), "$r");
          h(_assertThisInitialized(_this17), "$g");
          h(_assertThisInitialized(_this17), "$b");
          h(_assertThisInitialized(_this17), "$a");
          h(_assertThisInitialized(_this17), "hex", "");
          h(_assertThisInitialized(_this17), "r", 0);
          h(_assertThisInitialized(_this17), "g", 0);
          h(_assertThisInitialized(_this17), "b", 0);
          h(_assertThisInitialized(_this17), "a", 1);
          _this17.attachShadow({
            mode: "open"
          }), _this17.hsvChanged = _this17.hsvChanged.bind(_assertThisInitialized(_this17)), _this17.hueChanged = _this17.hueChanged.bind(_assertThisInitialized(_this17)), _this17.alphaChanged = _this17.alphaChanged.bind(_assertThisInitialized(_this17)), _this17.onHexChange = _this17.onHexChange.bind(_assertThisInitialized(_this17)), _this17.render = _this17.render.bind(_assertThisInitialized(_this17)), _this17.onRedChange = _this17.onRedChange.bind(_assertThisInitialized(_this17)), _this17.onGreenChange = _this17.onGreenChange.bind(_assertThisInitialized(_this17)), _this17.onBlueChange = _this17.onBlueChange.bind(_assertThisInitialized(_this17)), _this17.onAlphaChange = _this17.onAlphaChange.bind(_assertThisInitialized(_this17)), _this17.onRedKeyDown = _this17.onRedKeyDown.bind(_assertThisInitialized(_this17)), _this17.onBlueKeyDown = _this17.onBlueKeyDown.bind(_assertThisInitialized(_this17)), _this17.onGreenKeyDown = _this17.onGreenKeyDown.bind(_assertThisInitialized(_this17)), _this17.onAlphaKeyDown = _this17.onAlphaKeyDown.bind(_assertThisInitialized(_this17));
          return _this17;
        }
        var _proto14 = J.prototype;
        _proto14.hueChanged = function hueChanged(t) {
          if (!t || !t.detail || !t.detail.cid || t.detail.cid !== this.cid) return;
          var i = this.color.toHsv();
          this.color = new l({
            h: Number(t.detail.h),
            s: i.s,
            v: i.v,
            a: i.a
          }), this.render();
        };
        _proto14.alphaChanged = function alphaChanged(t) {
          if (!t || !t.detail || !t.detail.cid || t.detail.cid !== this.cid) return;
          var i = this.color.toRgb();
          i.a = t.detail.a, this.color = new l(i), this.render();
        };
        _proto14.hsvChanged = function hsvChanged(t) {
          !t || !t.detail || !t.detail.cid || t.detail.cid === this.cid && (this.color = new l({
            h: t.detail.h,
            s: t.detail.s,
            v: t.detail.v,
            a: this.color.toHsv().a
          }), this.render());
        };
        _proto14.render = function render() {
          var i, r, n, s, a;
          var t = this.color.toRgb();
          this.r = t.r, this.g = t.g, this.b = t.b, this.a = t.a, this.hex = this.color.toHex(), this.$hex && ((i = this.shadowRoot) == null ? void 0 : i.activeElement) !== this.$hex && (this.$hex.value = this.hex.toUpperCase()), this.$r && ((r = this.shadowRoot) == null ? void 0 : r.activeElement) !== this.$r && (this.$r.value = this.r.toString()), this.$g && ((n = this.shadowRoot) == null ? void 0 : n.activeElement) !== this.$g && (this.$g.value = this.g.toString()), this.$b && ((s = this.shadowRoot) == null ? void 0 : s.activeElement) !== this.$b && (this.$b.value = this.b.toString()), this.$a && ((a = this.shadowRoot) == null ? void 0 : a.activeElement) !== this.$a && (this.$a.value = Math.round(this.a * 100).toString());
        };
        _proto14.onFieldKeyDown = function onFieldKeyDown(t, i) {
          var n, s;
          var r = this.color.toRgb();
          switch (t.key) {
            case "ArrowUp":
              {
                if (i === "r") {
                  this.r = Math.min(255, r.r + 1), r.r = this.r;
                  var _a = new l(r).toHsv();
                  b(this.cid, _a.h, _a.s, _a.v), this.$r.value = this.r.toString(), this.render();
                }
                if (i === "g") {
                  this.g = Math.min(255, r.g + 1), r.g = this.g;
                  var _a2 = new l(r).toHsv();
                  b(this.cid, _a2.h, _a2.s, _a2.v), this.$g.value = this.g.toString(), this.render();
                }
                if (i === "b") {
                  this.b = Math.min(255, r.b + 1), r.b = this.b;
                  var _a3 = new l(r).toHsv();
                  b(this.cid, _a3.h, _a3.s, _a3.v), this.$b.value = this.b.toString(), this.render();
                }
                if (i === "a") {
                  this.a = Math.min(100, this.a + .01), this.$a.value = Math.round(this.a * 100).toString();
                  var _a4 = this.color.toRgb();
                  _a4.a = this.a, this.color = new l(_a4), this.render(), M(this.cid, this.a);
                }
                break;
              }
            case "ArrowDown":
              {
                if (i === "r") {
                  this.r = Math.max(0, r.r - 1), r.r = this.r;
                  var _a5 = new l(r).toHsv();
                  b(this.cid, _a5.h, _a5.s, _a5.v), this.$r.value = this.r.toString(), this.render();
                }
                if (i === "g") {
                  this.g = Math.max(0, r.g - 1), r.g = this.g;
                  var _a6 = new l(r).toHsv();
                  b(this.cid, _a6.h, _a6.s, _a6.v), this.$g.value = this.g.toString(), this.render();
                }
                if (i === "b") {
                  this.b = Math.max(0, r.b - 1), r.b = this.b;
                  var _a7 = new l(r).toHsv();
                  b(this.cid, _a7.h, _a7.s, _a7.v), this.$b.value = this.b.toString(), this.render();
                }
                if (i === "a") {
                  this.a = Math.max(0, this.a - .01), this.$a.value = Math.round(this.a * 100).toString();
                  var _a8 = this.color.toRgb();
                  _a8.a = this.a, this.color = new l(_a8), this.render(), M(this.cid, this.a);
                }
                break;
              }
            case "Escape":
              {
                (n = this.shadowRoot) != null && n.activeElement && this.shadowRoot.activeElement.blur(), this.render();
                break;
              }
            case "Enter":
              {
                (s = this.shadowRoot) != null && s.activeElement && this.shadowRoot.activeElement.blur(), this.render();
                break;
              }
          }
        };
        _proto14.onRedKeyDown = function onRedKeyDown(t) {
          this.onFieldKeyDown(t, "r");
        };
        _proto14.onGreenKeyDown = function onGreenKeyDown(t) {
          this.onFieldKeyDown(t, "g");
        };
        _proto14.onBlueKeyDown = function onBlueKeyDown(t) {
          this.onFieldKeyDown(t, "b");
        };
        _proto14.onAlphaKeyDown = function onAlphaKeyDown(t) {
          this.onFieldKeyDown(t, "a");
        };
        _proto14.onHexChange = function onHexChange(t) {
          var i = t.target;
          if (i.value.length !== 6) return;
          var r = new l(`#${i.value}`);
          if (r.isValid) {
            this.color = r;
            var _n = this.color.toHsv();
            b(this.cid, _n.h, _n.s, _n.v);
          }
        };
        _proto14.onRedChange = function onRedChange(t) {
          var i = t.target,
            r = I(i.value);
          if (r.toString() === i.value) {
            var _n2 = this.color.toRgb();
            _n2.r = r;
            var _s8 = new l(_n2).toHsv();
            b(this.cid, _s8.h, _s8.s, _s8.v);
          }
        };
        _proto14.onGreenChange = function onGreenChange(t) {
          var i = t.target,
            r = I(i.value);
          if (r.toString() === i.value) {
            var _n3 = this.color.toRgb();
            _n3.g = r;
            var _s9 = new l(_n3).toHsv();
            b(this.cid, _s9.h, _s9.s, _s9.v);
          }
        };
        _proto14.onBlueChange = function onBlueChange(t) {
          var i = t.target,
            r = I(i.value);
          if (r.toString() === i.value) {
            var _n4 = this.color.toRgb();
            _n4.b = r;
            var _s10 = new l(_n4).toHsv();
            b(this.cid, _s10.h, _s10.s, _s10.v);
          }
        };
        _proto14.onAlphaChange = function onAlphaChange(t) {
          var i = t.target,
            r = ft(i.value);
          r.toString() === i.value && M(this.cid, r / 100);
        };
        _proto14.connectedCallback = function connectedCallback() {
          if (!this.shadowRoot) return;
          this.cid = this.getAttribute("cid") || "", this.color = c(this.getAttribute("color"));
          var t = this.color.toRgb();
          this.r = t.r, this.g = t.g, this.b = t.b, this.a = t.a, this.hex = this.color.toHex();
          var i = $(),
            r = $(),
            n = $(),
            s = $(),
            a = $();
          this.shadowRoot.innerHTML = `
           <style>${Et}</style>
           <div class="fields">
               <input id="hex-${i}" type="text" value="${this.hex.toUpperCase()}" data-type="hex" />
               <input id="r-${r}" type="text" value="${this.r}" data-type="r" />
               <input id="g-${n}" type="text" value="${this.g}" data-type="g" />
               <input id="b-${s}" type="text" value="${this.b}" data-type="b" />
               <input id="a-${a}" type="text" value="${Math.round(this.a * 100)}" data-type="a" />
               
               <label for="hex-${i}">Hex</label>
               <label for="r-${r}">R</label>
               <label for="g-${n}">G</label>
               <label for="b-${s}">B</label>
               <label for="a-${a}">A</label>
           </div>
        `, this.$hex = this.shadowRoot.getElementById(`hex-${i}`), this.$r = this.shadowRoot.getElementById(`r-${r}`), this.$g = this.shadowRoot.getElementById(`g-${n}`), this.$b = this.shadowRoot.getElementById(`b-${s}`), this.$a = this.shadowRoot.getElementById(`a-${a}`), document.addEventListener(p, this.hsvChanged), document.addEventListener(f, this.hueChanged), document.addEventListener(m, this.alphaChanged), this.$hex.addEventListener("input", this.onHexChange), this.$r.addEventListener("input", this.onRedChange), this.$g.addEventListener("input", this.onGreenChange), this.$b.addEventListener("input", this.onBlueChange), this.$a.addEventListener("input", this.onAlphaChange), this.$hex.addEventListener("blur", this.render), this.$r.addEventListener("blur", this.render), this.$g.addEventListener("blur", this.render), this.$b.addEventListener("blur", this.render), this.$a.addEventListener("blur", this.render), this.$r.addEventListener("keydown", this.onRedKeyDown), this.$g.addEventListener("keydown", this.onGreenKeyDown), this.$b.addEventListener("keydown", this.onBlueKeyDown), this.$a.addEventListener("keydown", this.onAlphaKeyDown);
        };
        _proto14.disconnectedCallback = function disconnectedCallback() {
          document.removeEventListener(p, this.hsvChanged), document.removeEventListener(f, this.hueChanged), document.removeEventListener(m, this.alphaChanged), this.$hex.removeEventListener("input", this.onHexChange), this.$r.removeEventListener("input", this.onRedChange), this.$g.removeEventListener("input", this.onGreenChange), this.$b.removeEventListener("input", this.onBlueChange), this.$a.removeEventListener("input", this.onAlphaChange), this.$hex.removeEventListener("blur", this.render), this.$r.removeEventListener("blur", this.render), this.$g.removeEventListener("blur", this.render), this.$b.removeEventListener("blur", this.render), this.$a.removeEventListener("blur", this.render), this.$r.removeEventListener("keydown", this.onRedKeyDown), this.$g.removeEventListener("keydown", this.onGreenKeyDown), this.$b.removeEventListener("keydown", this.onBlueKeyDown), this.$a.removeEventListener("keydown", this.onAlphaKeyDown);
        };
        _proto14.attributeChangedCallback = function attributeChangedCallback(t, i, r) {
          this.color = c(r), this.render();
        };
        _createClass(J, null, [{
          key: "observedAttributes",
          get: function get() {
            return ["color"];
          }
        }]);
        return J;
      }( /*#__PURE__*/_wrapNativeSuper(HTMLElement)),
      Ct = J;
    var Z = /*#__PURE__*/function (_HTMLElement6) {
        _inheritsLoose(Z, _HTMLElement6);
        function Z() {
          var _this18;
          _this18 = _HTMLElement6.call(this) || this;
          h(_assertThisInitialized(_this18), "cid");
          h(_assertThisInitialized(_this18), "popupPosition", "left");
          h(_assertThisInitialized(_this18), "$popup");
          h(_assertThisInitialized(_this18), "color", "#000");
          customElements.get("toolcool-color-picker-saturation") || customElements.define("toolcool-color-picker-saturation", bt), customElements.get("toolcool-color-picker-hue") || customElements.define("toolcool-color-picker-hue", mt), customElements.get("toolcool-color-picker-alpha") || customElements.define("toolcool-color-picker-alpha", xt), customElements.get("toolcool-color-picker-fields") || customElements.define("toolcool-color-picker-fields", Ct), _this18.cid = _this18.getAttribute("cid") || "", _this18.prevent = _this18.prevent.bind(_assertThisInitialized(_this18)), _this18.attachShadow({
            mode: "open"
          });
          return _this18;
        }
        var _proto15 = Z.prototype;
        _proto15.prevent = function prevent(t) {
          t.stopPropagation();
        };
        _proto15.connectedCallback = function connectedCallback() {
          var t, i;
          !this.shadowRoot || (this.color = this.getAttribute("color") || "#000", this.popupPosition = this.getAttribute("popup-position") || "left", this.shadowRoot.innerHTML = `
           <style>${it}</style>
           <div class="popup">
                <toolcool-color-picker-saturation color="${this.color}" cid="${this.cid}"></toolcool-color-picker-saturation>
                <toolcool-color-picker-hue color="${this.color}" cid="${this.cid}"></toolcool-color-picker-hue>
                <toolcool-color-picker-alpha color="${this.color}" cid="${this.cid}"></toolcool-color-picker-alpha>
                <toolcool-color-picker-fields color="${this.color}" cid="${this.cid}"></toolcool-color-picker-fields>
           </div>
        `, this.$popup = this.shadowRoot.querySelector(".popup"), (t = this.$popup) == null || t.addEventListener("mousedown", this.prevent), (i = this.$popup) == null || i.classList.toggle("right", this.popupPosition === "right"));
        };
        _proto15.disconnectedCallback = function disconnectedCallback() {
          var t;
          (t = this.$popup) == null || t.removeEventListener("mousedown", this.prevent);
        };
        _proto15.attributeChangedCallback = function attributeChangedCallback(t, i, r) {
          var n, s, a, d;
          if (t === "popup-position" && (this.popupPosition = r, this.$popup && this.$popup.classList.toggle("right", this.popupPosition === "right")), t === "color") {
            this.color = r;
            var w = (n = this.shadowRoot) == null ? void 0 : n.querySelector("toolcool-color-picker-saturation"),
              _x = (s = this.shadowRoot) == null ? void 0 : s.querySelector("toolcool-color-picker-hue"),
              _R = (a = this.shadowRoot) == null ? void 0 : a.querySelector("toolcool-color-picker-alpha"),
              et = (d = this.shadowRoot) == null ? void 0 : d.querySelector("toolcool-color-picker-fields");
            w && w.setAttribute("color", this.color), _x && _x.setAttribute("color", this.color), _R && _R.setAttribute("color", this.color), et && et.setAttribute("color", this.color);
          }
        };
        _createClass(Z, null, [{
          key: "observedAttributes",
          get: function get() {
            return ["color", "popup-position"];
          }
        }]);
        return Z;
      }( /*#__PURE__*/_wrapNativeSuper(HTMLElement)),
      yt = Z;
    var Ut = {
        sm: "0.875rem",
        md: "1.2rem",
        lg: "1.5rem",
        xl: "2.25rem",
        "2xl": "3rem",
        "3xl": "3.75rem",
        "4xl": "4.5rem"
      },
      tt = /*#__PURE__*/function (_HTMLElement7) {
        _inheritsLoose(tt, _HTMLElement7);
        function tt() {
          var _this19;
          _this19 = _HTMLElement7.call(this) || this;
          h(_assertThisInitialized(_this19), "cid");
          h(_assertThisInitialized(_this19), "$button");
          h(_assertThisInitialized(_this19), "$buttonColor");
          h(_assertThisInitialized(_this19), "$popupBox");
          h(_assertThisInitialized(_this19), "stateDefaults", {
            isPopupVisible: !1,
            popupPosition: "left",
            initialColor: new l("#000"),
            color: new l("#000"),
            buttonWidth: null,
            buttonHeight: null,
            buttonPadding: null
          });
          h(_assertThisInitialized(_this19), "state");
          _this19.cid = $(), customElements.get("toolcool-color-picker-popup") || customElements.define("toolcool-color-picker-popup", yt), _this19.attachShadow({
            mode: "open"
          }), _this19.toggle = _this19.toggle.bind(_assertThisInitialized(_this19)), _this19.onKeyDown = _this19.onKeyDown.bind(_assertThisInitialized(_this19)), _this19.clickedOutside = _this19.clickedOutside.bind(_assertThisInitialized(_this19)), _this19.stopPropagation = _this19.stopPropagation.bind(_assertThisInitialized(_this19)), _this19.hsvChanged = _this19.hsvChanged.bind(_assertThisInitialized(_this19)), _this19.hueChanged = _this19.hueChanged.bind(_assertThisInitialized(_this19)), _this19.alphaChanged = _this19.alphaChanged.bind(_assertThisInitialized(_this19)), _this19.buttonClicked = _this19.buttonClicked.bind(_assertThisInitialized(_this19)), _this19.formatButtonSize = _this19.formatButtonSize.bind(_assertThisInitialized(_this19)), _this19.initState();
          return _this19;
        }
        var _proto16 = tt.prototype;
        _proto16.initState = function initState() {
          var t = this;
          this.state = new Proxy(t.stateDefaults, {
            set(i, r, n, s) {
              return i[r] = n, r === "isPopupVisible" && t.onPopupVisibilityChange(), r === "popupPosition" && t.onPopupPosChange(), r === "initialColor" && t.onInitialColorChange(), r === "color" && t.onColorChange(), (r === "buttonWidth" || r === "buttonHeight" || r === "buttonPadding") && t.setButtonSize(), !0;
            }
          });
        };
        _proto16.onPopupVisibilityChange = function onPopupVisibilityChange() {
          !this.$popupBox || (this.$popupBox.innerHTML = this.state.isPopupVisible ? `<toolcool-color-picker-popup color="${this.state.color.toRgbString()}" cid="${this.cid}" popup-position="${this.state.popupPosition}" />` : "");
        };
        _proto16.onPopupPosChange = function onPopupPosChange() {
          if (!this.$popupBox) return;
          var t = this.$popupBox.querySelector("toolcool-color-picker-popup");
          !t || t.setAttribute("popup-position", this.state.popupPosition);
        };
        _proto16.onInitialColorChange = function onInitialColorChange() {
          var r;
          var t = S(this.state.color);
          this.$buttonColor && (this.$buttonColor.style.backgroundColor = t);
          var i = (r = this.shadowRoot) == null ? void 0 : r.querySelector("toolcool-color-picker-popup");
          i && i.setAttribute("color", t);
        };
        _proto16.setButtonSize = function setButtonSize() {
          !this.$button || (this.state.buttonWidth && (this.$button.style.width = this.formatButtonSize(this.state.buttonWidth)), this.state.buttonHeight && (this.$button.style.height = this.formatButtonSize(this.state.buttonHeight)), this.state.buttonPadding && (this.$button.style.padding = this.state.buttonPadding));
        };
        _proto16.onColorChange = function onColorChange() {
          this.$buttonColor && (this.$buttonColor.style.backgroundColor = S(this.state.color)), this.dispatchEvent(new CustomEvent("change", {
            detail: {
              hex: this.hex,
              hex8: this.hex8,
              rgb: this.rgb,
              rgba: this.rgba,
              hsl: this.hsl,
              hsla: this.hsla,
              hsv: this.hsv,
              hsva: this.hsva,
              color: this.color
            }
          }));
        };
        _proto16.hsvChanged = function hsvChanged(t) {
          !t || !t.detail || !t.detail.cid || t.detail.cid === this.cid && (this.state.color = new l({
            h: t.detail.h,
            s: t.detail.s,
            v: t.detail.v,
            a: this.state.color.toHsv().a
          }));
        };
        _proto16.hueChanged = function hueChanged(t) {
          if (!t || !t.detail || !t.detail.cid || t.detail.cid !== this.cid) return;
          var i = this.state.color.toHsv();
          this.state.color = new l({
            h: t.detail.h,
            s: i.s,
            v: i.v,
            a: i.a
          });
        };
        _proto16.alphaChanged = function alphaChanged(t) {
          if (!t || !t.detail || !t.detail.cid || t.detail.cid !== this.cid) return;
          var i = this.state.color.toRgb();
          i.a = t.detail.a, this.state.color = new l(i);
        };
        _proto16.buttonClicked = function buttonClicked(t) {
          !t || !t.detail || !t.detail.cid || t.detail.cid !== this.cid && (this.state.isPopupVisible = !1);
        };
        _proto16.clickedOutside = function clickedOutside() {
          this.state.isPopupVisible = !1;
        };
        _proto16.toggle = function toggle() {
          var _this20 = this;
          var t = this.state.isPopupVisible;
          window.setTimeout(function () {
            _this20.state.isPopupVisible = !t, nt(_this20.cid);
          }, 0);
        };
        _proto16.onKeyDown = function onKeyDown(t) {
          t.key === "Escape" && (this.state.isPopupVisible = !1);
        };
        _proto16.stopPropagation = function stopPropagation(t) {
          t.stopPropagation();
        };
        _proto16.formatButtonSize = function formatButtonSize(t) {
          var i;
          return (i = Ut[t]) != null ? i : t;
        };
        _proto16.connectedCallback = function connectedCallback() {
          var t, i, r;
          !this.shadowRoot || (this.state.initialColor = c(this.getAttribute("color")), this.state.color = c(this.getAttribute("color")), this.state.popupPosition = this.getAttribute("popup-position") || "left", this.state.buttonWidth = this.getAttribute("button-width"), this.state.buttonHeight = this.getAttribute("button-height"), this.state.buttonPadding = this.getAttribute("button-padding"), this.shadowRoot.innerHTML = `
            <style>
                ${ot} 
            </style>
            <div class="color-picker" >
                <button
                    type="button"
                    tabIndex="0"
                    class="button"
                    title="Select Color">
                    <span class="button-color" style="background: ${S(this.state.color)};"></span>
                </button>
                <div data-popup-box></div>
            </div>
        `, this.$button = this.shadowRoot.querySelector(".button"), this.$buttonColor = this.shadowRoot.querySelector(".button-color"), (t = this.$button) == null || t.addEventListener("click", this.toggle), (i = this.$button) == null || i.addEventListener("keydown", this.onKeyDown), (r = this.$button) == null || r.addEventListener("mousedown", this.stopPropagation), this.$popupBox = this.shadowRoot.querySelector("[data-popup-box]"), this.setButtonSize(), document.addEventListener("mousedown", this.clickedOutside), document.addEventListener(p, this.hsvChanged), document.addEventListener(f, this.hueChanged), document.addEventListener(m, this.alphaChanged), document.addEventListener(D, this.buttonClicked));
        };
        _proto16.disconnectedCallback = function disconnectedCallback() {
          var t, i, r;
          (t = this.$button) == null || t.removeEventListener("click", this.toggle), (i = this.$button) == null || i.removeEventListener("keydown", this.onKeyDown), (r = this.$button) == null || r.removeEventListener("mousedown", this.stopPropagation), document.removeEventListener("mousedown", this.clickedOutside), document.removeEventListener(p, this.hsvChanged), document.removeEventListener(f, this.hueChanged), document.removeEventListener(m, this.alphaChanged), document.removeEventListener(D, this.buttonClicked);
        };
        _proto16.attributeChangedCallback = function attributeChangedCallback(t) {
          t === "color" && (this.state.initialColor = c(this.getAttribute("color")), this.state.color = c(this.getAttribute("color")), this.onInitialColorChange()), t === "popup-position" && (this.state.popupPosition = this.getAttribute("popup-position") || "left", this.onPopupPosChange()), t === "button-width" && (this.state.buttonWidth = this.getAttribute("button-width"), this.setButtonSize()), t === "button-height" && (this.state.buttonHeight = this.getAttribute("button-height"), this.setButtonSize()), t === "button-padding" && (this.state.buttonPadding = this.getAttribute("button-padding"), this.setButtonSize());
        };
        _createClass(tt, [{
          key: "color",
          get: function get() {
            return this.state.color;
          },
          set: function set(t) {
            this.state.color = new l(t);
          }
        }, {
          key: "hex",
          get: function get() {
            return this.state.color.toHexString().toUpperCase();
          }
        }, {
          key: "hex8",
          get: function get() {
            return this.state.color.toHex8String().toUpperCase();
          }
        }, {
          key: "rgb",
          get: function get() {
            return this.state.color.toRgbString();
          }
        }, {
          key: "rgba",
          get: function get() {
            return S(this.state.color);
          }
        }, {
          key: "hsl",
          get: function get() {
            return this.state.color.toHslString();
          }
        }, {
          key: "hsla",
          get: function get() {
            return pt(this.state.color);
          }
        }, {
          key: "hsv",
          get: function get() {
            return this.state.color.toHsvString();
          }
        }, {
          key: "hsva",
          get: function get() {
            return gt(this.state.color);
          }
        }, {
          key: "opened",
          get: function get() {
            return this.state.isPopupVisible;
          },
          set: function set(t) {
            this.state.isPopupVisible = t;
          }
        }], [{
          key: "observedAttributes",
          get: function get() {
            return ["color", "popup-position", "button-width", "button-height", "button-padding"];
          }
        }]);
        return tt;
      }( /*#__PURE__*/_wrapNativeSuper(HTMLElement)),
      $t = tt;
    customElements.get("toolcool-color-picker") || customElements.define("toolcool-color-picker", $t);
  })();
  var DgColor = /*#__PURE__*/function (_s11) {
    _inheritsLoose(DgColor, _s11);
    function DgColor() {
      var _this21;
      _this21 = _s11.call(this) || this;
      console.log(_this21.value);
      _this21.blueprint = {
        main: [{
          cssVariableName: 'hue',
          label: 'TPL_MUTA_COLORS_HUE',
          value: 214
        }],
        colors: [{
          cssVariableName: 'bs-link-color',
          label: 'TPL_MUTA_COLORS_SETTINGS_LINK_COLOR_LABEL',
          value: '#0d6efd'
        }, {
          cssVariableName: 'bs-link-color-rgb',
          label: '',
          value: '13, 110, 253'
        }, {
          cssVariableName: 'bs-link-hover-color',
          label: 'TPL_MUTA_COLORS_SETTINGS_LINK_HOVER_COLOR_LABEL',
          value: '#013a8e'
        }, {
          cssVariableName: 'bs-link-hover-color-rgb',
          label: '',
          value: '1, 58, 142'
        }],
        calculated: [{
          cssVariableName: 'template-bg-light',
          label: '',
          value: '#f0f4fb'
        }, {
          cssVariableName: 'template-text-dark',
          label: '',
          value: '#495057'
        }, {
          cssVariableName: 'template-text-light',
          label: '',
          value: '#ffffff'
        }, {
          cssVariableName: 'template-link-color',
          label: '',
          value: '#0d6efd'
        }, {
          cssVariableName: 'template-link-hover-color',
          label: '',
          value: '#0143a3'
        }, {
          cssVariableName: 'template-special-color',
          label: '',
          value: '#0d6efd'
        }, {
          cssVariableName: 'template-sidebar-bg',
          label: '',
          value: 'var(--template-bg-dark-80)'
        }, {
          cssVariableName: 'template-sidebar-font-color',
          label: '',
          value: '#fff'
        }, {
          cssVariableName: 'template-sidebar-link-color',
          label: '',
          value: '#fff'
        }, {
          cssVariableName: 'template-bg-light',
          label: '',
          value: '#f0f4fb'
        }, {
          cssVariableName: 'template-text-light',
          label: '',
          value: '#fff'
        }, {
          cssVariableName: 'template-contrast',
          label: '',
          value: '#0d6efd'
        }, {
          cssVariableName: 'template-bg-dark',
          label: '',
          value: 'hsl(var(--hue), 40%, 20%)'
        }, {
          cssVariableName: 'template-bg-dark-3',
          label: '',
          value: 'hsl(var(--hue), 40%, 97%)'
        }, {
          cssVariableName: 'template-bg-dark-5',
          label: '',
          value: 'hsl(var(--hue), 40%, 95%)'
        }, {
          cssVariableName: 'template-bg-dark-7',
          label: '',
          value: 'hsl(var(--hue), 40%, 93%)'
        }, {
          cssVariableName: 'template-bg-dark-10',
          label: '',
          value: 'hsl(var(--hue), 40%, 90%)'
        }, {
          cssVariableName: 'template-bg-dark-15',
          label: '',
          value: 'hsl(var(--hue), 40%, 85%)'
        }, {
          cssVariableName: 'template-bg-dark-20',
          label: '',
          value: 'hsl(var(--hue), 40%, 80%)'
        }, {
          cssVariableName: 'template-bg-dark-30',
          label: '',
          value: 'hsl(var(--hue), 40%, 70%)'
        }, {
          cssVariableName: 'template-bg-dark-40',
          label: '',
          value: 'hsl(var(--hue), 40%, 60%)'
        }, {
          cssVariableName: 'template-bg-dark-50',
          label: '',
          value: 'hsl(var(--hue), 40%, 50%)'
        }, {
          cssVariableName: 'template-bg-dark-60',
          label: '',
          value: 'hsl(var(--hue), 40%, 40%)'
        }, {
          cssVariableName: 'template-bg-dark-65',
          label: '',
          value: 'hsl(var(--hue), 40%, 35%)'
        }, {
          cssVariableName: 'template-bg-dark-70',
          label: '',
          value: 'hsl(var(--hue), 40%, 30%)'
        }, {
          cssVariableName: 'template-bg-dark-75',
          label: '',
          value: 'hsl(var(--hue), 40%, 25%)'
        }, {
          cssVariableName: 'template-bg-dark-80',
          label: '',
          value: 'hsl(var(--hue), 40%, 20%)'
        }, {
          cssVariableName: 'template-bg-dark-90',
          label: '',
          value: 'hsl(var(--hue), 40%, 10%)'
        }]
      };
      var fallback = JSON.parse('{"bs-link-color":"#144AAB","bs-link-color-rgb":"20, 74, 171","bs-link-hover-color":"#9EC5FE","bs-link-hover-color-rgb":"158,197,254","hue":"214","template-bg-light":"#f0f4fb","template-text-dark":"#495057","template-text-light":"#fff","template-link-color":"rgb(20, 74, 171)","template-link-hover-color":"rgb(14, 56, 108)","template-special-color":"#0d6efd","template-sidebar-bg":"var(--template-bg-dark-80)","template-sidebar-font-color":"#fff","template-sidebar-link-color":"#fff","template-contrast":"#0d6efd","template-bg-dark":"hsl(var(--hue), 40%, 20%)","template-bg-dark-3":"hsl(var(--hue), 40%, 97%)","template-bg-dark-5":"hsl(var(--hue), 40%, 95%)","template-bg-dark-7":"hsl(var(--hue), 40%, 93%)","template-bg-dark-10":"hsl(var(--hue), 40%, 90%)","template-bg-dark-15":"hsl(var(--hue), 40%, 85%)","template-bg-dark-20":"hsl(var(--hue), 40%, 80%)","template-bg-dark-30":"hsl(var(--hue), 40%, 70%)","template-bg-dark-40":"hsl(var(--hue), 40%, 60%)","template-bg-dark-50":"hsl(var(--hue), 40%, 50%)","template-bg-dark-60":"hsl(var(--hue), 40%, 40%)","template-bg-dark-65":"hsl(var(--hue), 40%, 35%)","template-bg-dark-70":"hsl(var(--hue), 40%, 30%)","template-bg-dark-75":"hsl(var(--hue), 40%, 25%)","template-bg-dark-80":"hsl(var(--hue), 40%, 20%)","template-bg-dark-90":"hsl(var(--hue), 40%, 10%)","bs-primary":"#0d6efd","bs-primary-rgb":"13, 110, 253"}');
      console.log(_this21.getAttribute('value'));
      console.log(JSON.parse(_this21.getAttribute('value')));
      try {
        _this21.value = JSON.parse(_this21.getAttribute('value'));
      } catch (e) {
        _this21.value = fallback;
      }
      if (!_this21.value.length) _this21.value = fallback;
      _this21.renderColors = _this21.renderColors.bind(_assertThisInitialized(_this21));
      _this21.applyColors = _this21.applyColors.bind(_assertThisInitialized(_this21));
      return _this21;
    }
    var _proto17 = DgColor.prototype;
    _proto17.createRenderRoot = function createRenderRoot() {
      return this; // Disable shadow DOM.
    };
    _proto17.connectedCallback = function connectedCallback() {
      _s11.prototype.connectedCallback.call(this);
      this.fields = this.blueprint.colors.filter(function (x) {
        return !x.cssVariableName.endsWith('-rgb');
      });
      this.sliderValue = this.value.hue;
    };
    _proto17.firstUpdated = function firstUpdated() {
      var _this$querySelector;
      (_this$querySelector = this.querySelector('input[type="hidden"]')) == null ? void 0 : _this$querySelector.remove();
    };
    _proto17.render = function render() {
      var _this22 = this;
      this.applyColors();
      return y`${this.createHueField()}${this.fields.map(function (field) {
      return _this22.createColorField(field);
    })}${this.renderColors()}<input type="hidden" name="${this.name}" .value='${JSON.stringify(this.value)}'>`;
    };
    _proto17.createHueField = function createHueField() {
      var _this23 = this;
      return y`<div class="control-group">
    <div class="control-label"><label id="jform_params_hue-lbl" for="jform_params_hue">Choose your hue value for the dark template colour</label></div>

    <div class="controls">
          <label for="slider-input" class="visually-hidden">Selected Colour Value</label>
          <input type="text" class="form-control" id="slider-input" pattern="[0-9]{1,3}" style="border: 2px solid rgb(19, 47, 83);" .value=${this.sliderValue} @input=${function (e) {
      _this23.sliderValue = e.target.value;
      _this23.value.hue = e.target.value;
      _this23.requestUpdate();
    }}>
          <label for="hue-slider" class="visually-hidden">Hue Slider</label>
          <input type="range" min="0" step="1" max="360" class="form-control color-slider" .value=${this.sliderValue} @input=${function (e) {
      _this23.sliderValue = e.target.value;
      _this23.value.hue = e.target.value;
      _this23.requestUpdate();
    }} style="background-image: linear-gradient(90deg, rgb(83, 19, 19), rgb(83, 19, 19), rgb(83, 38, 19), rgb(83, 57, 19), rgb(83, 77, 19), rgb(70, 83, 19), rgb(51, 83, 19), rgb(32, 83, 19), rgb(19, 83, 25), rgb(19, 83, 45), rgb(19, 83, 64), rgb(19, 83, 83), rgb(19, 64, 83), rgb(19, 45, 83), rgb(19, 25, 83), rgb(32, 19, 83), rgb(51, 19, 83), rgb(70, 19, 83), rgb(83, 19, 77), rgb(83, 19, 57), rgb(83, 19, 38), rgb(83, 19, 19), rgb(83, 19, 19)); appearance: none;">
      </div>
    </div>
</div>`;
    };
    _proto17.createColorField = function createColorField(field) {
      var _this$value,
        _this24 = this;
      return y`<div class="control-group">
    <div class="control-label"><label for=${field.cssVariableName}>${Joomla.Text._(field.label)}</label></div>
    <div class="controls">
      <toolcool-color-picker id=${field.cssVariableName} color=${(_this$value = this.value) == null ? void 0 : _this$value[field.cssVariableName]} @change=${function (e) {
      _this24.value[`${field.cssVariableName}-rgb`] = e.detail.rgb.replace('rgb(', '').replace(')', '');
      if (field.cssVariableName === 'bs-link-color') _this24.value['template-link-color'] = e.detail.rgb;
      if (field.cssVariableName === 'bs-link-hover-color') _this24.value['template-link-hover-color'] = e.detail.rgb;
      _this24.value[`${field.cssVariableName}`] = e.detail.hex;
      _this24.value[`${field.cssVariableName}-rgb`] = e.detail.rgb.replace('rgb(', '').replace(')', '');
      _this24.requestUpdate();
    }} button-width="8rem" button-height="3rem" button-padding="2px" style="--tool-cool-color-picker-popup-bg: var(--bs-body-bg); --tool-cool-color-picker-field-label-color: var(--bs-body-color)"></toolcool-color-picker>
    </div>
  </div>`;
    };
    _proto17.renderColors = function renderColors() {
      var _this$value2,
        _this25 = this;
      return y`<p>CSS Variables:</p>
    <pre><code>--hue: ${(_this$value2 = this.value) == null ? void 0 : _this$value2.hue};</code></pre>
    <pre><code>--bs-primary: ${this.value['link-color']};</code></pre>
    <pre><code>--bs-primary-rgb: ${this.value['link-color-rgb']};</code></pre>
    ${this.blueprint.colors.map(function (field) {
      var _this25$value;
      return y`<pre><code>--${field.cssVariableName}: ${(_this25$value = _this25.value) == null ? void 0 : _this25$value[field.cssVariableName]};</code></pre>`;
    })}
    ${this.blueprint.calculated.map(function (field) {
      var _this25$value2;
      return y`<pre><code>--${field.cssVariableName}: ${(_this25$value2 = _this25.value) == null ? void 0 : _this25$value2[field.cssVariableName]};</code></pre>`;
    })}
    `;
    };
    _proto17.applyColors = function applyColors() {
      var _this$value3, _this$value4, _this$value5, _this$value6;
      var root = document.querySelector(':root');
      for (var _i14 = 0, _Object$entries = Object.entries(this.value); _i14 < _Object$entries.length; _i14++) {
        var _Object$entries$_i = _Object$entries[_i14],
          key = _Object$entries$_i[0],
          value = _Object$entries$_i[1];
        root.style.setProperty(`--${key}`, value);
      }
      root.style.setProperty('--hue', (_this$value3 = this.value) == null ? void 0 : _this$value3.hue);
      root.style.setProperty('--bs-primary', (_this$value4 = this.value) == null ? void 0 : _this$value4['bs-link-color']);
      root.style.setProperty('--bs-primary-rgb', (_this$value5 = this.value) == null ? void 0 : _this$value5['bs-link-color-rgb']);
      root.style.setProperty('accent-color', (_this$value6 = this.value) == null ? void 0 : _this$value6['bs-link-color']);
    };
    _createClass(DgColor, null, [{
      key: "properties",
      get: function get() {
        return {
          value: {
            type: Object,
            value: {}
          },
          name: {
            type: String,
            value: 'muta-colors'
          }
        };
      }
    }]);
    return DgColor;
  }(s);
  customElements.define('dg-color-field', DgColor);

})();
